// ═══════════════════════════════════════════════════════════════════
// scripts/import-recipes-csv.ts
// One-time script to import 12,000 recipes from CSV into Supabase.
//
// Run with:  npx tsx scripts/import-recipes-csv.ts
//
// CSV columns expected:
// RecipeName, Zone, Is_Foreign, Cuisine, Course, Diet,
// TotalTimeInMins, Servings, Ingredients, Instructions, URL
// ═══════════════════════════════════════════════════════════════════

import * as fs from "fs";
import * as path from "path";
import { Pool } from "pg";
import * as dotenv from "dotenv";
dotenv.config();

// ─── Lightweight CSV parser (no dependency needed) ─────────────────
function parseCSV(content: string): Record<string, string>[] {
  const lines = content.split("\n");
  if (lines.length < 2) return [];

  const headers = parseCSVLine(lines[0]).map((h) =>
    h.trim().replace(/^\uFEFF/, "") // strip BOM if present
  );

  const rows: Record<string, string>[] = [];
  for (let i = 1; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    const values = parseCSVLine(line);
    const row: Record<string, string> = {};
    headers.forEach((h, idx) => {
      row[h] = (values[idx] ?? "").trim();
    });
    rows.push(row);
  }
  return rows;
}

function parseCSVLine(line: string): string[] {
  const result: string[] = [];
  let current = "";
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    if (char === '"') {
      if (inQuotes && line[i + 1] === '"') {
        current += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (char === "," && !inQuotes) {
      result.push(current);
      current = "";
    } else {
      current += char;
    }
  }
  result.push(current);
  return result;
}

// ─── Zone → region_group mapping ──────────────────────────────────
// Maps the raw Zone column values from the CSV to your normalised
// region_group values that the SQL filter uses.
function mapZoneToRegionGroup(zone: string): string {
  const z = zone.toLowerCase().trim();
  if (z.includes("north east") || z.includes("northeast")) return "northeast_india";
  if (z.includes("north")) return "north_india";
  if (z.includes("south")) return "south_india";
  if (z.includes("east")) return "east_india";
  if (z.includes("west")) return "west_india";
  if (z.includes("central")) return "central_india";
  if (!z || z === "" || z.includes("no specific") || z.includes("pan")) return "pan_indian";
  return "pan_indian"; // safe fallback
}

// ─── Diet → dietary_tags mapping ──────────────────────────────────
// Maps the raw Diet column to your normalised dietary_tags array.
function mapDietToDietaryTags(diet: string): string[] {
  const d = diet.toLowerCase().trim();
  if (d.includes("vegan")) return ["vegan", "vegetarian"];
  if (d.includes("eggetarian")) return ["eggetarian", "vegetarian"];
  if (d.includes("non veg") || d.includes("non-veg")) return ["non_veg"];
  if (d.includes("vegetarian") || d.includes("veg")) return ["vegetarian"];
  return ["vegetarian"]; // default safe fallback
}

// ─── Course → meal_type mapping ───────────────────────────────────
// Maps the raw Course column to your normalised meal_type array.
function mapCourseToMealType(course: string): string[] {
  const c = course.toLowerCase().trim();
  const types: string[] = [];

  if (
    c.includes("breakfast") ||
    c.includes("morning")
  ) types.push("breakfast");

  if (
    c.includes("main course") ||
    c.includes("main dish") ||
    c.includes("lunch") ||
    c.includes("dinner")
  ) {
    types.push("lunch", "dinner");
  }

  if (
    c.includes("snack") ||
    c.includes("appetizer") ||
    c.includes("starter") ||
    c.includes("side dish")
  ) types.push("snack");

  if (c.includes("dessert") || c.includes("sweet")) types.push("snack");

  // If nothing matched, mark as lunch + dinner (safe default)
  if (types.length === 0) types.push("lunch", "dinner");

  return [...new Set(types)];
}

// ─── Cook time → skill level ───────────────────────────────────────
function mapTimeToCookingSkill(totalTimeMinStr: string): string {
  const mins = parseInt(totalTimeMinStr) || 0;
  if (mins <= 20) return "beginner";
  if (mins <= 45) return "intermediate";
  return "experienced";
}

// ─── Is_Foreign string → boolean ──────────────────────────────────
function parseIsForeign(val: string): boolean {
  const v = val.toLowerCase().trim();
  return v === "true" || v === "yes" || v === "1" || v === "foreign";
}

// ═══════════════════════════════════════════════════════════════════
// MAIN IMPORT FUNCTION
// ═══════════════════════════════════════════════════════════════════
async function importRecipesCSV() {
  const csvPath = process.argv[2] || path.join(__dirname, "../data/recipes.csv");

  if (!fs.existsSync(csvPath)) {
    console.error(`CSV file not found at: ${csvPath}`);
    console.error("Usage: npx tsx scripts/import-recipes-csv.ts ./data/recipes.csv");
    process.exit(1);
  }

  console.log(`Reading CSV from: ${csvPath}`);
  const content = fs.readFileSync(csvPath, "utf-8");
  const rows = parseCSV(content);
  console.log(`Parsed ${rows.length} rows from CSV`);

  // ── Connect directly to Supabase PostgreSQL ──────────────────────
  const pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    ssl: { rejectUnauthorized: false },
    max: 5,
  });

  const BATCH_SIZE = 200; // Insert 200 rows per query — optimal for pg
  let imported = 0;
  let skipped = 0;

  for (let i = 0; i < rows.length; i += BATCH_SIZE) {
    const batch = rows.slice(i, i + BATCH_SIZE);

    // Build the VALUES clause for bulk insert
    const values: any[] = [];
    const placeholders: string[] = [];
    let paramIdx = 1;

    for (const row of batch) {
      const recipeName = row["RecipeName"] || row["recipe_name"] || "";
      if (!recipeName.trim()) {
        skipped++;
        continue;
      }

      const zone = row["Zone"] || row["zone"] || "";
      const isForeign = parseIsForeign(row["Is_Foreign"] || row["is_foreign"] || "false");
      const cuisine = row["Cuisine"] || row["cuisine"] || "";
      const course = row["Course"] || row["course"] || "";
      const diet = row["Diet"] || row["diet"] || "Vegetarian";
      const totalTimeMins = parseInt(row["TotalTimeInMins"] || row["total_time_mins"] || "0") || null;
      const servings = parseInt(row["Servings"] || row["servings"] || "0") || null;
      const ingredients = row["Ingredients"] || row["ingredients"] || "";
      const instructions = row["Instructions"] || row["instructions"] || "";
      const url = row["URL"] || row["url"] || "";

      const regionGroup = mapZoneToRegionGroup(zone);
      const dietaryTags = mapDietToDietaryTags(diet);
      const mealType = mapCourseToMealType(course);
      const skillLevel = mapTimeToCookingSkill(String(totalTimeMins || 0));

      placeholders.push(
        `($${paramIdx++}, $${paramIdx++}, $${paramIdx++}, $${paramIdx++}, $${paramIdx++}, $${paramIdx++}, $${paramIdx++}, $${paramIdx++}, $${paramIdx++}, $${paramIdx++}, $${paramIdx++}, $${paramIdx++}, $${paramIdx++}, $${paramIdx++}, $${paramIdx++})`
      );

      values.push(
        recipeName,           // recipe_name
        zone,                 // zone
        isForeign,            // is_foreign
        cuisine,              // cuisine
        course,               // course
        diet,                 // diet
        totalTimeMins,        // total_time_mins
        servings,             // servings
        ingredients,          // ingredients
        instructions,         // instructions
        url,                  // url
        regionGroup,          // region_group (derived)
        `{${dietaryTags.join(",")}}`,  // dietary_tags (pg array literal)
        `{${mealType.join(",")}}`,     // meal_type (pg array literal)
        skillLevel            // cooking_skill_req (derived)
      );
    }

    if (placeholders.length === 0) continue;

    const query = `
      INSERT INTO recipes (
        recipe_name, zone, is_foreign, cuisine, course, diet,
        total_time_mins, servings, ingredients, instructions, url,
        region_group, dietary_tags, meal_type, cooking_skill_req
      )
      VALUES ${placeholders.join(", ")}
      ON CONFLICT DO NOTHING
    `;

    try {
      await pool.query(query, values);
      imported += placeholders.length;
      process.stdout.write(`\rImported: ${imported}/${rows.length} | Skipped: ${skipped}`);
    } catch (err) {
      console.error(`\nBatch error at row ${i}:`, (err as Error).message);
      // Continue with next batch — don't abort the whole import
    }
  }

  await pool.end();

  console.log(`\n\n✅ Import complete!`);
  console.log(`   Imported: ${imported}`);
  console.log(`   Skipped:  ${skipped}`);
  console.log(`\nNext step: Run the tagging script to populate allergen_tags and health_tags`);
  console.log(`  npx tsx scripts/tag-recipes-batch.ts`);
}

importRecipesCSV().catch((err) => {
  console.error("Fatal import error:", err);
  process.exit(1);
});
