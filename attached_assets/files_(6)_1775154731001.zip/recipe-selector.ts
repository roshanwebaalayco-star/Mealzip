// ═══════════════════════════════════════════════════════════════════
// src/engine/recipe-selector.ts
//
// This is the SQL filter layer — it runs between the Conflict Engine
// and the Gemini Scheduler call.
//
// Input:  Conflict engine output (allergies, diet, conditions, time)
// Output: 80-120 recipe names (the "Approved List" for Gemini)
//
// Performance target: < 500ms (GIN indexes on Supabase make this easy)
// ═══════════════════════════════════════════════════════════════════

import { Pool } from "pg";
import {
  getDirectRegionGroup,
  getBroadenedRegionGroups,
  getAllRegionGroups,
} from "./region-mapper";
import type {
  EffectiveMemberProfile,
  PreGenerationConstraints,
} from "./types";

// ─── Types ─────────────────────────────────────────────────────────

export interface RecipeCandidate {
  id: string;
  recipeName: string;
  mealType: string[];      // ['breakfast'] | ['lunch','dinner'] etc.
  regionGroup: string;
  healthTags: string[];
  dietaryTags: string[];
  fastingFriendly: boolean;
  totalTimeMins: number | null;
  popularityScore: number;
  source: "database";      // All candidates from DB are tagged "database"
}

export interface RecipeSelectorResult {
  candidates: RecipeCandidate[];
  coverageScore: number;       // 0–100: how well DB covers the need
  fallbackLayer: 1 | 2 | 3;   // which layer was needed
  fallbackTriggered: boolean;
  coverageNarrative: string;   // passed to Gemini prompt as context
  breakdownByMealType: {
    breakfast: number;
    lunch: number;
    dinner: number;
    snack: number;
  };
}

// ─── Diet → dietary_tags SQL filter ──────────────────────────────
// Given the family's household dietary baseline and all member dietary
// types, returns the SQL condition for the dietary_tags column.
// Rule: the SQL filter uses the MOST PERMISSIVE member's dietary type
// as the upper bound. Gemini then restricts per-member via plate mods.
function buildDietaryFilter(profiles: EffectiveMemberProfile[]): {
  requireTags: string[];    // ALL of these must be in dietary_tags
  excludeDietTypes: string[]; // recipes must NOT be these diet types
} {
  const dietTypes = new Set(profiles.map((p) => p.dietaryType));

  const hasNonVeg =
    dietTypes.has("non_vegetarian") || dietTypes.has("occasional_non_veg");
  const hasEgg = dietTypes.has("eggetarian");
  const hasJain = dietTypes.has("jain_vegetarian");
  const allVeg = [...dietTypes].every(
    (d) => d === "strictly_vegetarian" || d === "jain_vegetarian"
  );

  // If everyone is strictly vegetarian: require "vegetarian" tag
  // If family has non-veg members: no dietary restriction on SQL layer
  // (Gemini handles per-member plate restriction)
  // If family has Jain member: ALSO include jain_friendly recipes

  const requireTags: string[] = [];
  const excludeDietTypes: string[] = [];

  if (allVeg) {
    requireTags.push("vegetarian");
    excludeDietTypes.push("non_veg"); // belt-and-suspenders
  } else if (hasEgg && !hasNonVeg) {
    // Eggetarian family: vegetarian + egg dishes allowed
    // No SQL restriction needed — egg dishes have "eggetarian" tag
    // Exclude pure non-veg (meat/fish)
    excludeDietTypes.push("non_veg");
  }
  // Mixed/non-veg family: no dietary restriction at SQL level

  // Jain member is handled at plate level, not at recipe exclusion level
  // (otherwise we'd miss too many recipes for other members)

  return { requireTags, excludeDietTypes };
}

// ─── Allergy → allergen_tags exclusion ───────────────────────────
// Any recipe that CONTAINS an allergen of ANY family member is excluded.
// This is Level 1 — absolute, never violated.
function buildAllergenExclusion(profiles: EffectiveMemberProfile[]): string[] {
  const allAllergens = new Set<string>();
  for (const profile of profiles) {
    for (const allergy of profile.allergies) {
      if (allergy !== "none") {
        allAllergens.add(allergy);
      }
    }
  }
  return [...allAllergens];
}

// ─── Health tags → health_tags preference ────────────────────────
// Recipes with matching health tags get higher priority (ORDER BY),
// but we don't exclude recipes without them — Gemini handles per-member.
function buildHealthTagPreferences(
  profiles: EffectiveMemberProfile[]
): string[] {
  const healthTags = new Set<string>();
  const allConditions = profiles.flatMap((p) => p.effectiveHealthConditions);

  if (allConditions.includes("diabetes_type_2")) {
    healthTags.add("diabetic_friendly");
    healthTags.add("low_gi");
  }
  if (allConditions.includes("hypertension")) {
    healthTags.add("low_sodium");
  }
  if (allConditions.includes("anaemia")) {
    healthTags.add("high_iron");
  }
  if (
    allConditions.includes("kidney_issues")
  ) {
    healthTags.add("kidney_friendly");
  }

  return [...healthTags];
}

// ─── Cook time limit ──────────────────────────────────────────────
function buildCookTimeLimit(weekdayCookingTime: string): number {
  switch (weekdayCookingTime) {
    case "under_20_mins": return 25;    // slight buffer
    case "20_40_mins": return 50;       // slight buffer
    case "no_limit": return 999;
    default: return 60;
  }
}

// ═══════════════════════════════════════════════════════════════════
// THE MAIN SQL FILTER — 3-LAYER FALLBACK
// ═══════════════════════════════════════════════════════════════════

export async function selectRecipeCandidates(
  pool: Pool,
  family: { stateRegion: string; mealsPerDay: string },
  weeklyContext: { weekdayCookingTime: string; hasFastingMembersThisWeek: boolean },
  profiles: EffectiveMemberProfile[],
  constraints: PreGenerationConstraints
): Promise<RecipeSelectorResult> {

  const cookTimeLimit = buildCookTimeLimit(weeklyContext.weekdayCookingTime);
  const allergenExclusions = buildAllergenExclusion(profiles);
  const { requireTags: dietaryRequire } = buildDietaryFilter(profiles);
  const healthTagPreferences = buildHealthTagPreferences(profiles);
  const needsFastingRecipes = weeklyContext.hasFastingMembersThisWeek;

  // ── Layer 1: Tight regional filter ────────────────────────────
  const layer1RegionGroup = getDirectRegionGroup(family.stateRegion);

  let candidates = await runRecipeQuery(pool, {
    regionGroups: [layer1RegionGroup, "pan_indian"],
    allergenExclusions,
    dietaryRequireTags: dietaryRequire,
    cookTimeMax: cookTimeLimit,
    healthTagPreferences,
    includeFastingRecipes: needsFastingRecipes,
    excludeForeign: true,
    limit: 120,
  });

  const MINIMUM_VIABLE = 42; // Need at least 2× the 21 meals we schedule

  if (candidates.length >= MINIMUM_VIABLE) {
    return buildResult(candidates, 1, false, family.stateRegion);
  }

  // ── Layer 2: Broaden to regional group ─────────────────────────
  console.log(
    `[RecipeSelector] Layer 1 returned ${candidates.length} (need ${MINIMUM_VIABLE}). Broadening to regional group...`
  );

  const layer2RegionGroups = getBroadenedRegionGroups(family.stateRegion);

  candidates = await runRecipeQuery(pool, {
    regionGroups: layer2RegionGroups,
    allergenExclusions,
    dietaryRequireTags: dietaryRequire,
    cookTimeMax: cookTimeLimit,
    healthTagPreferences,
    includeFastingRecipes: needsFastingRecipes,
    excludeForeign: true,
    limit: 120,
  });

  if (candidates.length >= MINIMUM_VIABLE) {
    return buildResult(candidates, 2, true, family.stateRegion);
  }

  // ── Layer 3: All Indian recipes (pan_indian catch-all) ─────────
  console.log(
    `[RecipeSelector] Layer 2 returned ${candidates.length}. Falling back to all Indian recipes...`
  );

  candidates = await runRecipeQuery(pool, {
    regionGroups: ["north_india", "south_india", "east_india", "west_india", "central_india", "northeast_india", "pan_indian"],
    allergenExclusions,
    dietaryRequireTags: dietaryRequire,
    cookTimeMax: cookTimeLimit,
    healthTagPreferences,
    includeFastingRecipes: needsFastingRecipes,
    excludeForeign: true, // still avoid foreign recipes in layer 3
    limit: 120,
  });

  return buildResult(candidates, 3, true, family.stateRegion);
}

// ─── Core SQL query builder ────────────────────────────────────────
interface QueryParams {
  regionGroups: string[];
  allergenExclusions: string[];
  dietaryRequireTags: string[];
  cookTimeMax: number;
  healthTagPreferences: string[];
  includeFastingRecipes: boolean;
  excludeForeign: boolean;
  limit: number;
}

async function runRecipeQuery(
  pool: Pool,
  params: QueryParams
): Promise<RecipeCandidate[]> {
  const {
    regionGroups,
    allergenExclusions,
    dietaryRequireTags,
    cookTimeMax,
    healthTagPreferences,
    includeFastingRecipes,
    excludeForeign,
    limit,
  } = params;

  // Build parameterised query dynamically
  const sqlParams: any[] = [];
  const conditions: string[] = [];

  // ── Condition 1: Region filter ──────────────────────────────────
  // region_group IN ('east_india', 'pan_indian')
  sqlParams.push(regionGroups);
  conditions.push(`region_group = ANY($${sqlParams.length}::text[])`);

  // ── Condition 2: Exclude foreign recipes ───────────────────────
  if (excludeForeign) {
    conditions.push(`is_foreign = FALSE`);
  }

  // ── Condition 3: Allergen exclusion (HARD — Level 1 safety) ───
  // Exclude any recipe that CONTAINS any allergen of any family member
  // SQL: NOT (allergen_tags && ARRAY['peanuts','dairy'])
  if (allergenExclusions.length > 0) {
    sqlParams.push(allergenExclusions);
    conditions.push(
      `NOT (allergen_tags && $${sqlParams.length}::text[])`
    );
  }

  // ── Condition 4: Dietary requirement ──────────────────────────
  // If family is all-veg, require 'vegetarian' tag
  // dietary_tags @> ARRAY['vegetarian'] means the tag MUST be present
  if (dietaryRequireTags.length > 0) {
    sqlParams.push(dietaryRequireTags);
    conditions.push(
      `dietary_tags @> $${sqlParams.length}::text[]`
    );
  }

  // ── Condition 5: Cook time limit ──────────────────────────────
  if (cookTimeMax < 999) {
    sqlParams.push(cookTimeMax);
    conditions.push(
      `(total_time_mins IS NULL OR total_time_mins <= $${sqlParams.length})`
    );
  }

  const whereClause =
    conditions.length > 0 ? `WHERE ${conditions.join(" AND ")}` : "";

  // ── ORDER BY: prioritise health-relevant recipes + popularity ──
  // If we have health tag preferences, boost recipes that match them
  let orderByClause = "ORDER BY popularity_score DESC";
  if (healthTagPreferences.length > 0) {
    sqlParams.push(healthTagPreferences);
    // Recipes matching health tags get +1.0 boost in sort order
    orderByClause = `ORDER BY (
        CASE WHEN health_tags && $${sqlParams.length}::text[] THEN 1.0 ELSE 0.0 END
        + popularity_score
      ) DESC`;
  }

  // ── Fasting recipes: fetch separately to ensure inclusion ──────
  // Main query: non-fasting recipes (the majority of the week)
  sqlParams.push(limit);
  const limitClause = `LIMIT $${sqlParams.length}`;

  const mainQuery = `
    SELECT
      id,
      recipe_name,
      meal_type,
      region_group,
      health_tags,
      dietary_tags,
      fasting_friendly,
      total_time_mins,
      popularity_score
    FROM recipes
    ${whereClause}
    AND (fasting_friendly = FALSE OR fasting_friendly IS NULL)
    ${orderByClause}
    ${limitClause}
  `;

  const mainResult = await pool.query<{
    id: string;
    recipe_name: string;
    meal_type: string[];
    region_group: string;
    health_tags: string[];
    dietary_tags: string[];
    fasting_friendly: boolean;
    total_time_mins: number | null;
    popularity_score: string;
  }>(mainQuery, sqlParams);

  const candidates: RecipeCandidate[] = mainResult.rows.map((row) => ({
    id: row.id,
    recipeName: row.recipe_name,
    mealType: row.meal_type ?? [],
    regionGroup: row.region_group,
    healthTags: row.health_tags ?? [],
    dietaryTags: row.dietary_tags ?? [],
    fastingFriendly: row.fasting_friendly ?? false,
    totalTimeMins: row.total_time_mins,
    popularityScore: parseFloat(row.popularity_score) || 0.5,
    source: "database",
  }));

  // ── Fasting recipes: add if week has fasting members ──────────
  if (includeFastingRecipes) {
    // Build a separate fasting query — same allergen + dietary filters
    // but ONLY fasting_friendly = TRUE
    const fastingParams: any[] = [];
    const fastingConditions: string[] = [`fasting_friendly = TRUE`];

    if (allergenExclusions.length > 0) {
      fastingParams.push(allergenExclusions);
      fastingConditions.push(`NOT (allergen_tags && $${fastingParams.length}::text[])`);
    }
    if (dietaryRequireTags.length > 0) {
      fastingParams.push(dietaryRequireTags);
      fastingConditions.push(`dietary_tags @> $${fastingParams.length}::text[]`);
    }

    const fastingQuery = `
      SELECT
        id, recipe_name, meal_type, region_group, health_tags,
        dietary_tags, fasting_friendly, total_time_mins, popularity_score
      FROM recipes
      WHERE ${fastingConditions.join(" AND ")}
      ORDER BY popularity_score DESC
      LIMIT 15
    `;

    const fastingResult = await pool.query(fastingQuery, fastingParams);

    for (const row of fastingResult.rows) {
      candidates.push({
        id: row.id,
        recipeName: row.recipe_name,
        mealType: row.meal_type ?? [],
        regionGroup: row.region_group,
        healthTags: row.health_tags ?? [],
        dietaryTags: row.dietary_tags ?? [],
        fastingFriendly: true,
        totalTimeMins: row.total_time_mins,
        popularityScore: parseFloat(row.popularity_score) || 0.5,
        source: "database",
      });
    }
  }

  return candidates;
}

// ─── Result builder ────────────────────────────────────────────────
function buildResult(
  candidates: RecipeCandidate[],
  layer: 1 | 2 | 3,
  fallbackTriggered: boolean,
  stateRegion: string
): RecipeSelectorResult {
  const coverageScore = Math.min(100, Math.round((candidates.length / 42) * 100));

  const byMealType = {
    breakfast: candidates.filter((c) => c.mealType.includes("breakfast")).length,
    lunch: candidates.filter((c) => c.mealType.includes("lunch")).length,
    dinner: candidates.filter((c) => c.mealType.includes("dinner")).length,
    snack: candidates.filter((c) => c.mealType.includes("snack")).length,
  };

  let coverageNarrative: string;
  if (layer === 1) {
    coverageNarrative = `✅ Full regional coverage: ${candidates.length} recipes from ${stateRegion} and pan-Indian cuisine available.`;
  } else if (layer === 2) {
    coverageNarrative = `⚠️ Regional coverage ${coverageScore}% (Layer 2 active): ${candidates.length} recipes from broader region. Gemini should fill any gaps with authentic dishes from ${stateRegion}.`;
  } else {
    coverageNarrative = `⚠️ Regional coverage low (Layer 3 active): ${candidates.length} pan-Indian recipes found. Gemini should supplement with authentic ${stateRegion} regional dishes from its own knowledge for this week.`;
  }

  return {
    candidates,
    coverageScore,
    fallbackLayer: layer,
    fallbackTriggered,
    coverageNarrative,
    breakdownByMealType: byMealType,
  };
}
