// ═══════════════════════════════════════════════════════════════════
// src/engine/meal-generation-orchestrator.ts  [UPDATED SECTIONS]
//
// This shows ONLY the updated sections of the orchestrator —
// specifically how recipe selection slots into the pipeline between
// the conflict engine and the Gemini scheduler call.
//
// Replace the corresponding sections in your existing orchestrator.
// ═══════════════════════════════════════════════════════════════════

import { Pool } from "pg";
import { selectRecipeCandidates, type RecipeSelectorResult } from "./recipe-selector";
import type {
  Family,
  WeeklyContext,
  EffectiveMemberProfile,
  PreGenerationConstraints,
  MonthlyBudget,
  GenerationStep,
} from "./types";

// ─── Updated runGenerationPipeline ────────────────────────────────
// Insert this AFTER the conflict engine step and BEFORE the Gemini calls.
// The pool is your existing pg.Pool from db/index.ts
//
// Add this parameter to runGenerationPipeline:
//   pool: Pool
// And call it from orchestrateMealGeneration as:
//   runGenerationPipeline(weeklyContextId, familyId, mealPlanId, pool)

export async function runRecipeSelectionStep(
  pool: Pool,
  family: Family,
  weeklyContext: WeeklyContext,
  effectiveProfiles: EffectiveMemberProfile[],
  constraints: PreGenerationConstraints,
  mealPlanId: string,
  appendLog: (step: GenerationStep) => Promise<void>
): Promise<RecipeSelectorResult> {

  const stepStart = Date.now();

  // Check if any member is fasting this week
  const hasFastingMembers = effectiveProfiles.some(
    (p) => p.effectiveFastingDays.length > 0 || p.ekadashiThisWeek || p.festivalFastThisWeek
  );

  await appendLog({
    message: `Scanning recipe database for ${family.stateRegion} cuisine...`,
    duration_ms: 0,
    completed: false,
  });

  const result = await selectRecipeCandidates(
    pool,
    {
      stateRegion: family.stateRegion,
      mealsPerDay: family.mealsPerDay,
    },
    {
      weekdayCookingTime: weeklyContext.weekdayCookingTime,
      hasFastingMembersThisWeek: hasFastingMembers,
    },
    effectiveProfiles,
    constraints
  );

  const duration = Date.now() - stepStart;

  await appendLog({
    message: `Found ${result.candidates.length} recipe candidates (Layer ${result.fallbackLayer}) — ${result.breakdownByMealType.breakfast} breakfast, ${result.breakdownByMealType.lunch} lunch/dinner, ${result.breakdownByMealType.snack} snack options`,
    duration_ms: duration,
    completed: true,
  });

  return result;
}

// ─── Gemini Scheduler Prompt (updated with recipe anchor block) ───
// This replaces the meal generation prompt in prompt-builder.ts.
// The key change: Gemini receives recipe NAMES as anchors, not steps.
// It only outputs a schedule JSON — NOT cooking instructions.

export function buildSchedulerPrompt(
  family: Family,
  effectiveProfiles: EffectiveMemberProfile[],
  monthlyBudget: MonthlyBudget,
  weeklyContext: WeeklyContext,
  constraints: PreGenerationConstraints,
  recipeResult: RecipeSelectorResult,
  weekDates: Array<{ date: string; day: string }>
): string {

  // Build the approved recipe list block grouped by meal type
  const byMealType = {
    breakfast: recipeResult.candidates
      .filter((c) => c.mealType.includes("breakfast"))
      .map((c) => c.recipeName),
    lunch: recipeResult.candidates
      .filter((c) => c.mealType.includes("lunch"))
      .map((c) => c.recipeName),
    dinner: recipeResult.candidates
      .filter((c) => c.mealType.includes("dinner"))
      .map((c) => c.recipeName),
    snack: recipeResult.candidates
      .filter((c) => c.mealType.includes("snack"))
      .map((c) => c.recipeName),
    fasting: recipeResult.candidates
      .filter((c) => c.fastingFriendly)
      .map((c) => c.recipeName),
  };

  // Build fasting schedule string
  const fastingLines = effectiveProfiles
    .filter((p) => p.effectiveFastingDays.length > 0 || p.ekadashiThisWeek)
    .map((p) => {
      const days = [...p.effectiveFastingDays];
      if (p.ekadashiThisWeek) days.push("ekadashi_day");
      return `${p.memberName}: fasting on ${days.join(", ")}`;
    })
    .join("\n");

  // Build member IDs reference
  const memberRef = effectiveProfiles
    .map((p) => `"${p.memberId}" = ${p.memberName} (${p.dietaryType}, goal: ${p.effectiveGoal})`)
    .join(", ");

  // Build clinical modifiers block (hardcoded from conflict engine — NOT from Gemini)
  const clinicalBlock = effectiveProfiles
    .map((p) => {
      const lines: string[] = [`${p.memberName}:`];
      if (p.effectiveHealthConditions.filter((c) => c !== "none").length > 0) {
        lines.push(`  Conditions: ${p.effectiveHealthConditions.filter((c) => c !== "none").join(", ")}`);
      }
      if (p.allergies.filter((a) => a !== "none").length > 0) {
        lines.push(`  NEVER: ${constraints.absoluteNeverIngredients.get(p.memberId)?.slice(0, 5).join(", ")}`);
      }
      if (p.effectiveFastingDays.length > 0) {
        lines.push(`  Fasting: ${p.effectiveFastingDays.join(", ")}`);
      }
      return lines.join("\n");
    })
    .join("\n---\n");

  return `You are NutriNext's meal scheduler for an Indian family.

YOUR ONLY JOB: Pick exactly 21 meals from the approved list below and arrange 
them into a 7-day calendar. Apply the clinical modifiers to individual members.
DO NOT write cooking steps, ingredient quantities, or recipe instructions.
Output ONLY the schedule JSON described below.

=== FAMILY ===
${family.name} | ${family.stateRegion} | ${effectiveProfiles.length} members
${recipeResult.coverageNarrative}

=== WEEK DATES ===
${weekDates.map((d) => `${d.date} (${d.day})`).join("\n")}

=== SPECIAL REQUEST (OVERRIDE PRIORITY) ===
${weeklyContext.specialRequest || "None"}

=== BUDGET LIMITS (per meal slot per day) ===
Breakfast: ₹${monthlyBudget.budgetBreakdown.daily_limits.breakfast}
Lunch: ₹${monthlyBudget.budgetBreakdown.daily_limits.lunch}
Dinner: ₹${monthlyBudget.budgetBreakdown.daily_limits.dinner}

=== CLINICAL MODIFIERS (apply exactly as stated — do not reason about these) ===
${clinicalBlock}

=== FASTING SCHEDULE ===
${fastingLines || "No fasting days this week."}

=== APPROVED RECIPE LIST ===
Pick from these names. If a meal slot has no suitable match, write an authentic 
${family.stateRegion} dish name from your knowledge and mark source as "ai_generated".

BREAKFAST OPTIONS (${byMealType.breakfast.length}):
${byMealType.breakfast.slice(0, 40).join(" | ") || "None — generate from regional knowledge"}

LUNCH OPTIONS (${byMealType.lunch.length}):
${byMealType.lunch.slice(0, 40).join(" | ") || "None — generate from regional knowledge"}

DINNER OPTIONS (${byMealType.dinner.length}):
${byMealType.dinner.slice(0, 40).join(" | ") || "None — generate from regional knowledge"}

SNACK OPTIONS (${byMealType.snack.length}):
${byMealType.snack.slice(0, 20).join(" | ") || "None — generate from regional knowledge"}

FASTING RECIPES (${byMealType.fasting.length}):
${byMealType.fasting.join(" | ") || "None — generate sabudana/kuttu dishes as needed"}

=== SELECTION RULES ===
1. No dish name repeats more than once in the 7-day plan.
2. Breakfast must be quick (under 30 mins if possible from the approved list).
3. Fasting days: replace that member's meal with a fasting recipe or AI-generated fasting dish.
4. Use variety: do not put rice-based dishes for both lunch and dinner on the same day.
5. Member IDs for the output: ${memberRef}

=== OUTPUT FORMAT ===
Return ONLY this JSON. No prose. No markdown. No cooking steps.

{
  "days": [
    {
      "date": "YYYY-MM-DD",
      "day_name": "Monday",
      "meals": {
        "breakfast": {
          "dish_name": string,
          "source": "database" | "ai_generated",
          "estimated_cost_inr": number,
          "member_modifiers": [
            {
              "member_id": string,
              "member_name": string,
              "is_fasting": false,
              "fasting_replacement": null,
              "clinical_modifiers": []
            }
          ]
        },
        "lunch": { ... same shape ... },
        "dinner": { ... same shape ... }
      }
    }
  ]
}

clinical_modifiers is an array of SHORT instruction strings.
Examples:
- "Use Jowar roti instead of wheat roti"
- "Half salt, add lemon"
- "No ghee — use minimal oil"
- "Extra dal serving for protein"
- "Avoid potato — replace with lauki"
These come ONLY from the clinical block above. Do not invent new modifiers.

member_modifiers must include ALL ${effectiveProfiles.length} members in every meal.
Begin generating the 7-day schedule now.`;
}

// ─── Lazy-load recipe endpoint prompt ─────────────────────────────
// Called ONLY when user taps a specific meal to cook it.
// This is the ONLY time Gemini writes actual cooking steps.

export function buildRecipeDetailPrompt(
  dishName: string,
  memberModifiers: Array<{
    memberName: string;
    clinicalModifiers: string[];
    isFasting: boolean;
    fastingReplacement?: string;
    tiffinNeeded: string;
  }>,
  familyRegion: string,
  cookingSkillLevel: string,
  availableAppliances: string[]
): string {
  const modifierBlock = memberModifiers
    .map((m) => {
      if (m.isFasting && m.fastingReplacement) {
        return `${m.memberName}: SERVING "${m.fastingReplacement}" instead (fasting day)`;
      }
      const mods = m.clinicalModifiers.length > 0
        ? m.clinicalModifiers.join("; ")
        : "no modifications";
      const tiffin = m.tiffinNeeded !== "no"
        ? ` | TIFFIN: pack separately for ${m.tiffinNeeded}`
        : "";
      return `${m.memberName}: ${mods}${tiffin}`;
    })
    .join("\n");

  return `You are NutriNext's recipe writer for an Indian family.

Generate the complete recipe for: ${dishName}
Region: ${familyRegion} (use authentic regional preparation)
Skill level: ${cookingSkillLevel}
Available appliances: ${availableAppliances.join(", ")}

MEMBER PLATE MODIFICATIONS (inject into the recipe steps exactly as shown):
${modifierBlock}

OUTPUT FORMAT — return ONLY this JSON:
{
  "dish_name": "${dishName}",
  "prep_time_mins": number,
  "cook_time_mins": number,
  "servings": number,
  "image_search_query": string,
  "ingredients": [
    { "name": string, "quantity": string, "notes": string | null }
  ],
  "steps": [
    {
      "step_number": number,
      "instruction": string,
      "member_notes": [
        { "member_name": string, "note": string }
      ]
    }
  ],
  "member_plates": [
    {
      "member_name": string,
      "serving_description": string,
      "modifications_applied": [string],
      "is_fasting_replacement": boolean
    }
  ],
  "storage_tip": string | null,
  "tiffin_packing_notes": string | null
}

RULES FOR STEPS:
- member_notes inside a step is an array — only include members who have a 
  modification that applies to THIS specific step.
- Example: Step 3 "Add salt to taste" → member_note for Papa: "Add only half salt for Papa. Add lemon instead."
- Do not repeat all member notes in every step — only where the modification applies.
- image_search_query should be English, e.g. "Palak Dal Indian recipe"
- Write authentic ${familyRegion} style preparation.`;
}
