-- ═══════════════════════════════════════════════════════════════════
-- NUTRINEXT — RECIPES TABLE
-- Run this in Supabase SQL Editor BEFORE importing the CSV.
-- Columns are designed around the actual CSV structure:
-- RecipeName, Zone, Is_Foreign, Cuisine, Course, Diet,
-- TotalTimeInMins, Servings, Ingredients, Instructions, URL
-- ═══════════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS recipes (

  -- ── Primary Key ───────────────────────────────────────────────
  id                  UUID        PRIMARY KEY DEFAULT gen_random_uuid(),

  -- ── Raw columns from CSV (never modified after import) ────────
  recipe_name         TEXT        NOT NULL,
  zone                TEXT,
  -- Raw value from CSV e.g. 'North India', 'South India', 'East India',
  -- 'West India', 'North East India', 'Central India', 'No specific zone'

  is_foreign          BOOLEAN     NOT NULL DEFAULT FALSE,
  -- CSV column: Is_Foreign — true = non-Indian recipe, false = Indian
  -- We PREFER false (Indian) but fall back to true only if needed

  cuisine             TEXT,
  -- Raw value e.g. 'Bengali', 'Punjabi', 'Rajasthani', 'Tamil', etc.

  course              TEXT,
  -- Raw value e.g. 'Main Course', 'Breakfast', 'Snack', 'Dessert', 'Side Dish'

  diet                TEXT,
  -- Raw value e.g. 'Vegetarian', 'Non Vegeterian', 'Vegan', 'Eggetarian'

  total_time_mins     INTEGER,
  servings            INTEGER,
  ingredients         TEXT,        -- raw comma-separated string from CSV
  instructions        TEXT,        -- raw cooking steps from CSV
  url                 TEXT,

  -- ── Derived filter columns (populated by tagging script) ──────
  -- These are what the SQL WHERE clause actually uses.
  -- GIN indexes on array columns = sub-50ms queries on 12,000 rows.

  region_group        TEXT,
  -- Normalised from Zone column:
  -- 'north_india' | 'south_india' | 'east_india' | 'west_india' |
  -- 'central_india' | 'northeast_india' | 'pan_indian'

  dietary_tags        TEXT[]      NOT NULL DEFAULT '{}',
  -- Normalised from Diet column + AI-derived:
  -- 'vegetarian' | 'vegan' | 'eggetarian' | 'non_veg' |
  -- 'jain_friendly' | 'sattvic'

  allergen_tags       TEXT[]      NOT NULL DEFAULT '{}',
  -- Allergens PRESENT in this recipe (derived by tagging script):
  -- 'peanuts' | 'dairy' | 'gluten' | 'tree_nuts' |
  -- 'shellfish' | 'soy' | 'sesame'

  meal_type           TEXT[]      NOT NULL DEFAULT '{}',
  -- Normalised from Course column:
  -- 'breakfast' | 'lunch' | 'dinner' | 'snack'

  health_tags         TEXT[]      NOT NULL DEFAULT '{}',
  -- Derived by tagging script from ingredients:
  -- 'diabetic_friendly' | 'low_sodium' | 'high_protein' |
  -- 'high_iron' | 'low_gi' | 'high_fibre' | 'kidney_friendly'

  fasting_friendly    BOOLEAN     NOT NULL DEFAULT FALSE,
  -- true = suitable for Hindu fasting (sabudana, kuttu, fruits, dairy, sendha namak)

  cooking_skill_req   TEXT,
  -- 'beginner' | 'intermediate' | 'experienced'
  -- Derived from total_time_mins + complexity of instructions

  popularity_score    NUMERIC(4,3) NOT NULL DEFAULT 0.500,
  -- 0.000 to 1.000. Set to 0.700 for popular Indian staples,
  -- 0.500 default, lower for rare dishes.

  tags_generated_at   TIMESTAMPTZ,
  -- Timestamp when the tagging job ran for this recipe

  created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── GIN Indexes (array column lookups — the WHERE clause operators) ──────
-- && = overlaps (any match), @> = contains (exact match)
CREATE INDEX IF NOT EXISTS recipes_region_group_idx
  ON recipes(region_group);

CREATE INDEX IF NOT EXISTS recipes_dietary_tags_gin
  ON recipes USING GIN(dietary_tags);

CREATE INDEX IF NOT EXISTS recipes_allergen_tags_gin
  ON recipes USING GIN(allergen_tags);

CREATE INDEX IF NOT EXISTS recipes_meal_type_gin
  ON recipes USING GIN(meal_type);

CREATE INDEX IF NOT EXISTS recipes_health_tags_gin
  ON recipes USING GIN(health_tags);

CREATE INDEX IF NOT EXISTS recipes_is_foreign_idx
  ON recipes(is_foreign);

CREATE INDEX IF NOT EXISTS recipes_fasting_idx
  ON recipes(fasting_friendly);

CREATE INDEX IF NOT EXISTS recipes_total_time_idx
  ON recipes(total_time_mins);

CREATE INDEX IF NOT EXISTS recipes_popularity_idx
  ON recipes(popularity_score DESC);

-- Composite index for the most common combined query pattern:
-- region_group + dietary_tags + total_time_mins
CREATE INDEX IF NOT EXISTS recipes_main_filter_idx
  ON recipes(region_group, is_foreign, total_time_mins);

-- ── Row Level Security ─────────────────────────────────────────────────────
-- Recipes are read-only for all authenticated users.
-- Only the service role (your backend with SERVICE_ROLE_KEY) can write.
ALTER TABLE recipes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Recipes readable by authenticated users"
  ON recipes FOR SELECT
  USING (auth.role() = 'authenticated');

CREATE POLICY "Service role can do everything on recipes"
  ON recipes FOR ALL
  USING (auth.role() = 'service_role');
