-- ═══════════════════════════════════════════════════════════════════
-- VERIFICATION QUERIES
-- Run these in Supabase SQL Editor after import and tagging
-- to confirm everything is working correctly.
-- ═══════════════════════════════════════════════════════════════════

-- 1. How many recipes imported?
SELECT COUNT(*) AS total_recipes FROM recipes;

-- 2. How many are tagged vs untagged?
SELECT
  COUNT(*) AS total,
  COUNT(*) FILTER (WHERE tags_generated_at IS NOT NULL) AS tagged,
  COUNT(*) FILTER (WHERE tags_generated_at IS NULL) AS untagged
FROM recipes;

-- 3. Region distribution — does your data have good coverage?
SELECT
  region_group,
  COUNT(*) AS recipe_count
FROM recipes
GROUP BY region_group
ORDER BY recipe_count DESC;

-- 4. Diet distribution
SELECT
  unnest(dietary_tags) AS diet_tag,
  COUNT(*) AS count
FROM recipes
GROUP BY diet_tag
ORDER BY count DESC;

-- 5. Meal type distribution
SELECT
  unnest(meal_type) AS meal,
  COUNT(*) AS count
FROM recipes
GROUP BY meal
ORDER BY count DESC;

-- 6. Fasting-friendly count
SELECT
  fasting_friendly,
  COUNT(*) AS count
FROM recipes
GROUP BY fasting_friendly;

-- 7. Allergen presence (how many recipes have each allergen)
SELECT
  unnest(allergen_tags) AS allergen,
  COUNT(*) AS count
FROM recipes
GROUP BY allergen
ORDER BY count DESC;

-- ─────────────────────────────────────────────────────────────────
-- TEST QUERY: Simulate the actual SQL filter for a Jharkhand family
-- This is exactly what recipe-selector.ts runs (Layer 1)
-- ─────────────────────────────────────────────────────────────────
-- For: vegetarian family, no peanut allergy, weekday cooking < 50 mins
SELECT
  recipe_name,
  region_group,
  dietary_tags,
  meal_type,
  health_tags,
  total_time_mins,
  popularity_score
FROM recipes
WHERE
  -- Layer 1: east_india + pan_indian
  region_group = ANY(ARRAY['east_india', 'pan_indian'])
  -- No foreign recipes
  AND is_foreign = FALSE
  -- No peanut allergy (example)
  AND NOT (allergen_tags && ARRAY['peanuts']::text[])
  -- Must be vegetarian
  AND dietary_tags @> ARRAY['vegetarian']::text[]
  -- Cook time limit (weekday 40 mins + buffer)
  AND (total_time_mins IS NULL OR total_time_mins <= 50)
ORDER BY
  -- Boost diabetic-friendly recipes if family has diabetic member
  (CASE WHEN health_tags && ARRAY['diabetic_friendly', 'low_gi']::text[] THEN 1.0 ELSE 0.0 END
   + popularity_score) DESC
LIMIT 120;

-- ─────────────────────────────────────────────────────────────────
-- USEFUL MAINTENANCE QUERIES
-- ─────────────────────────────────────────────────────────────────

-- Reset tags for a recipe (to re-tag it)
-- UPDATE recipes SET tags_generated_at = NULL WHERE recipe_name = 'Some Recipe';

-- Reset ALL tags (to re-run the entire tagging job)
-- UPDATE recipes SET
--   allergen_tags = '{}',
--   health_tags = '{}',
--   fasting_friendly = FALSE,
--   tags_generated_at = NULL;

-- Find recipes with no meal_type (edge case from import)
-- SELECT recipe_name, course FROM recipes WHERE array_length(meal_type, 1) IS NULL LIMIT 20;

-- Check if GIN indexes exist
SELECT
  indexname,
  indexdef
FROM pg_indexes
WHERE tablename = 'recipes'
ORDER BY indexname;
