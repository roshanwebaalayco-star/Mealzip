// ═══════════════════════════════════════════════════════════════════
// src/engine/region-mapper.ts
// Maps family state/region → recipe region_group values for SQL filter.
// This is the bridge between the family profile and the recipe database.
//
// The 3-layer fallback system:
//   Layer 1: Direct state match (e.g., "jharkhand" → "east_india")
//   Layer 2: Broadened regional group (adds neighbouring zones)
//   Layer 3: pan_indian (catch-all — Gemini fills gaps from knowledge)
// ═══════════════════════════════════════════════════════════════════

// ─── State → Zone mapping ──────────────────────────────────────────
// Maps normalised state names to the primary region_group.
// Mirrors the Zone column values from the CSV.
const STATE_TO_REGION_GROUP: Record<string, string> = {
  // East India
  jharkhand: "east_india",
  bihar: "east_india",
  west_bengal: "east_india",
  odisha: "east_india",
  chhattisgarh: "east_india", // bordering east

  // North India
  delhi: "north_india",
  uttar_pradesh: "north_india",
  haryana: "north_india",
  punjab: "north_india",
  himachal_pradesh: "north_india",
  uttarakhand: "north_india",
  jammu_and_kashmir: "north_india",
  ladakh: "north_india",
  rajasthan: "north_india",

  // South India
  tamil_nadu: "south_india",
  kerala: "south_india",
  karnataka: "south_india",
  andhra_pradesh: "south_india",
  telangana: "south_india",
  puducherry: "south_india",

  // West India
  maharashtra: "west_india",
  gujarat: "west_india",
  goa: "west_india",

  // Central India
  madhya_pradesh: "central_india",
  // chhattisgarh is in east group (covered above)

  // Northeast India
  assam: "northeast_india",
  meghalaya: "northeast_india",
  manipur: "northeast_india",
  mizoram: "northeast_india",
  nagaland: "northeast_india",
  arunachal_pradesh: "northeast_india",
  sikkim: "northeast_india",
  tripura: "northeast_india",
};

// ─── Region group → neighbouring groups for Layer 2 broadening ────
// When Layer 1 returns < 42 recipes, we add these neighbouring zones
// to the filter to increase the candidate pool.
const REGION_NEIGHBOURS: Record<string, string[]> = {
  east_india: ["east_india", "central_india", "north_india", "pan_indian"],
  north_india: ["north_india", "central_india", "west_india", "pan_indian"],
  south_india: ["south_india", "pan_indian"],
  west_india: ["west_india", "north_india", "central_india", "pan_indian"],
  central_india: ["central_india", "north_india", "east_india", "pan_indian"],
  northeast_india: ["northeast_india", "east_india", "pan_indian"],
  pan_indian: ["pan_indian"],
};

// ─── Cuisine → region_group mapping ──────────────────────────────
// Some recipes have Cuisine instead of Zone. Use as a fallback.
const CUISINE_TO_REGION_GROUP: Record<string, string> = {
  bengali: "east_india",
  bihari: "east_india",
  odia: "east_india",
  "oriya": "east_india",
  jharkhand: "east_india",
  punjabi: "north_india",
  mughlai: "north_india",
  awadhi: "north_india",
  kashmiri: "north_india",
  haryanvi: "north_india",
  rajasthani: "north_india",
  "north indian": "north_india",
  tamil: "south_india",
  "tamil nadu": "south_india",
  kerala: "south_india",
  chettinad: "south_india",
  karnataka: "south_india",
  andhra: "south_india",
  hyderabadi: "south_india",
  "south indian": "south_india",
  maharashtrian: "west_india",
  gujarati: "west_india",
  goan: "west_india",
  "maharashtra": "west_india",
  malvani: "west_india",
  madhya_pradesh: "central_india",
  mp: "central_india",
  chattisgarhi: "east_india",
  assamese: "northeast_india",
  manipuri: "northeast_india",
  nagaland: "northeast_india",
  "pan indian": "pan_indian",
  "indian": "pan_indian",
};

// ═══════════════════════════════════════════════════════════════════
// PUBLIC API
// ═══════════════════════════════════════════════════════════════════

/**
 * Normalises a raw state/region string from the family profile
 * into a consistent key for lookup.
 */
export function normaliseRegion(stateRegion: string): string {
  return stateRegion
    .toLowerCase()
    .trim()
    .replace(/\s+/g, "_")
    .replace(/-/g, "_");
}

/**
 * Layer 1 — direct region group for the family's state.
 * Returns a single region_group string.
 */
export function getDirectRegionGroup(stateRegion: string): string {
  const key = normaliseRegion(stateRegion);
  return STATE_TO_REGION_GROUP[key] ?? "pan_indian";
}

/**
 * Layer 2 — broadened region groups including neighbours.
 * Returns an array of region_group strings for the SQL IN clause.
 */
export function getBroadenedRegionGroups(stateRegion: string): string[] {
  const primary = getDirectRegionGroup(stateRegion);
  return REGION_NEIGHBOURS[primary] ?? ["pan_indian"];
}

/**
 * Layer 3 — pan_indian fallback.
 * Always returns all groups — used when DB coverage is very low.
 */
export function getAllRegionGroups(): string[] {
  return [
    "north_india",
    "south_india",
    "east_india",
    "west_india",
    "central_india",
    "northeast_india",
    "pan_indian",
  ];
}

/**
 * Given a raw Zone or Cuisine string from the CSV,
 * returns the normalised region_group (used during import and tagging).
 */
export function mapRawZoneToRegionGroup(zone: string): string {
  const z = zone.toLowerCase().trim().replace(/-/g, " ");
  if (z.includes("north east") || z.includes("northeast")) return "northeast_india";
  if (z.includes("north")) return "north_india";
  if (z.includes("south")) return "south_india";
  if (z.includes("east")) return "east_india";
  if (z.includes("west")) return "west_india";
  if (z.includes("central")) return "central_india";
  if (!z || z.includes("no specific") || z.includes("pan indian")) return "pan_indian";

  // Try cuisine name fallback
  const cuisineMatch = CUISINE_TO_REGION_GROUP[z];
  if (cuisineMatch) return cuisineMatch;

  return "pan_indian";
}
