// ═══════════════════════════════════════════════════════════════════
// scripts/tag-recipes-batch.ts
// One-time script to run Gemini tagging on all 12,000 recipes.
// Fills: allergen_tags, health_tags, fasting_friendly, popularity_score
//
// Run with: npx tsx scripts/tag-recipes-batch.ts
//
// Cost: ~₹150-200 in Gemini API credits for 12,000 recipes.
// Time: ~20-30 minutes. Safe to interrupt and resume — uses 
//       tags_generated_at to skip already-tagged recipes.
// ═══════════════════════════════════════════════════════════════════

import { Pool } from "pg";
import * as dotenv from "dotenv";
dotenv.config();

const GEMINI_API_URL =
  "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent";

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false },
  max: 3,
});

// ─── Gemini caller ─────────────────────────────────────────────────
async function callGemini(prompt: string): Promise<string> {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) throw new Error("GEMINI_API_KEY not set");

  const res = await fetch(`${GEMINI_API_URL}?key=${apiKey}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [{ role: "user", parts: [{ text: prompt }] }],
      generationConfig: { temperature: 0.1, maxOutputTokens: 4096 },
    }),
  });

  if (!res.ok) {
    const txt = await res.text();
    throw new Error(`Gemini API ${res.status}: ${txt.slice(0, 200)}`);
  }

  const data = await res.json() as any;
  return data.candidates?.[0]?.content?.parts?.[0]?.text ?? "";
}

function parseJSON<T>(raw: string): T {
  const stripped = raw
    .replace(/^```(?:json)?\s*/im, "")
    .replace(/\s*```\s*$/im, "")
    .trim();
  return JSON.parse(stripped) as T;
}

// ─── Tagging prompt ────────────────────────────────────────────────
// We pass 30 recipes at a time with name + ingredients only.
// Gemini does NOT write recipe steps here — it only classifies.
function buildTaggingPrompt(
  recipes: Array<{ id: string; recipe_name: string; ingredients: string; diet: string; zone: string }>
): string {
  return `You are a food safety and nutrition classifier for an Indian family health app.

For each recipe below, return a JSON array where each object has EXACTLY this shape:

{
  "id": "<same id as input — do not change>",
  "allergen_tags": [],     
  "health_tags": [],       
  "fasting_friendly": false,
  "popularity_score": 0.5,
  "jain_friendly": false,
  "sattvic_friendly": false
}

RULES FOR allergen_tags (allergens PRESENT in the recipe, not excluded):
Use only these exact values: "peanuts", "dairy", "gluten", "tree_nuts", "shellfish", "soy", "sesame"
- "dairy" = if recipe has milk, curd, paneer, ghee, butter, cream, khoya
- "gluten" = if recipe has wheat, atta, maida, suji, semolina, bread, roti dough
- "peanuts" = if recipe has groundnuts, mungfali, peanut oil
- "tree_nuts" = if recipe has almonds, cashews, walnuts, pistachios
- "shellfish" = if recipe has prawns, shrimp, crab, lobster
- "soy" = if recipe has soya chunks, tofu, soy sauce
- "sesame" = if recipe has til, sesame seeds, tahini

RULES FOR health_tags:
Use only these exact values: "diabetic_friendly", "low_sodium", "high_protein", "high_iron", "low_gi", "high_fibre", "kidney_friendly"
- "diabetic_friendly" = low GI, no white sugar, no maida, dal-based or vegetable-based
- "low_sodium" = no added salt heavy ingredients, no pickles, no papads in dish
- "high_protein" = main protein source is dal, paneer, eggs, meat, soya, rajma, chana
- "high_iron" = main ingredients include palak, rajma, chana, methi, sesame, dates, jaggery
- "low_gi" = dal-based, millet-based, or primarily vegetable-based with low sugar
- "high_fibre" = contains whole grains, millets, rajma, chana, lots of vegetables
- "kidney_friendly" = low protein, low potassium, low phosphorus (simple vegetable dishes, no heavy dal, no dairy excess)

RULES FOR fasting_friendly:
true ONLY if the recipe uses ONLY fasting-approved ingredients:
sabudana, kuttu atta, singhara atta, rajgira, fruits, milk, curd, paneer, 
sendha namak (rock salt), dry fruits, sweet potato — AND uses NO regular salt, 
NO wheat, NO rice (except sama rice / barnyard millet), NO onion, NO garlic

RULES FOR popularity_score (0.0 to 1.0):
- 0.9: Extremely common Indian household dish (dal tadka, roti, khichdi, aloo gobi, chana masala, rajma, palak paneer, idli, dosa, poha)
- 0.7: Common regional dish known across India (kadhi, sambar, rasam, biryani, pulao)  
- 0.5: Standard recipe, moderately common
- 0.3: Less common, regional speciality
- 0.1: Rare, very regional, or unusual

RULES FOR jain_friendly:
true ONLY if recipe has NO: onion, garlic, potato, carrot, beetroot, radish, turnip, 
sweet potato, yam, leek, spring onion, shallots

RULES FOR sattvic_friendly:
true ONLY if recipe has NO: onion, garlic, meat, eggs, alcohol — but CAN have dairy

Output ONLY the JSON array. No prose. No markdown. No explanation.
The array must have exactly ${recipes.length} objects in the same order as input.

RECIPES TO CLASSIFY:
${JSON.stringify(
  recipes.map((r) => ({
    id: r.id,
    name: r.recipe_name,
    ingredients: r.ingredients?.slice(0, 500), // trim long ingredients
    diet: r.diet,
    zone: r.zone,
  }))
)}`;
}

// ═══════════════════════════════════════════════════════════════════
// MAIN TAGGING LOOP
// ═══════════════════════════════════════════════════════════════════
async function tagRecipesBatch() {
  const BATCH_SIZE = 30;  // 30 recipes per Gemini call — sweet spot
  const DELAY_MS = 1500;  // 1.5s between calls — avoids rate limits

  console.log("🏷️  NutriNext Recipe Tagging Script");
  console.log("   Fetching untagged recipes...\n");

  // Count total untagged
  const countRes = await pool.query<{ count: string }>(
    `SELECT COUNT(*) as count FROM recipes WHERE tags_generated_at IS NULL`
  );
  const totalUntagged = parseInt(countRes.rows[0].count);
  console.log(`   Found ${totalUntagged} untagged recipes.\n`);

  if (totalUntagged === 0) {
    console.log("✅ All recipes are already tagged!");
    await pool.end();
    return;
  }

  let totalTagged = 0;
  let totalErrors = 0;

  while (true) {
    // Fetch next batch of untagged recipes
    const fetchRes = await pool.query<{
      id: string;
      recipe_name: string;
      ingredients: string;
      diet: string;
      zone: string;
    }>(
      `SELECT id, recipe_name, ingredients, diet, zone 
       FROM recipes 
       WHERE tags_generated_at IS NULL 
       ORDER BY id 
       LIMIT $1`,
      [BATCH_SIZE]
    );

    if (fetchRes.rows.length === 0) break; // All done

    const batch = fetchRes.rows;

    try {
      const prompt = buildTaggingPrompt(batch);
      const raw = await callGemini(prompt);
      
      const tags = parseJSON<Array<{
        id: string;
        allergen_tags: string[];
        health_tags: string[];
        fasting_friendly: boolean;
        popularity_score: number;
        jain_friendly: boolean;
        sattvic_friendly: boolean;
      }>>(raw);

      // Write tags back to DB for each recipe in the batch
      for (const tag of tags) {
        // Build the final dietary_tags: start from DB value, add jain/sattvic
        const additionalDietaryTags: string[] = [];
        if (tag.jain_friendly) additionalDietaryTags.push("jain_friendly");
        if (tag.sattvic_friendly) additionalDietaryTags.push("sattvic");

        await pool.query(
          `UPDATE recipes SET
            allergen_tags       = $1::text[],
            health_tags         = $2::text[],
            fasting_friendly    = $3,
            popularity_score    = $4,
            dietary_tags        = array_cat(dietary_tags, $5::text[]),
            tags_generated_at   = NOW(),
            updated_at          = NOW()
          WHERE id = $6`,
          [
            `{${tag.allergen_tags.join(",")}}`,
            `{${tag.health_tags.join(",")}}`,
            tag.fasting_friendly,
            Math.min(1.0, Math.max(0.0, tag.popularity_score)),
            `{${additionalDietaryTags.join(",")}}`,
            tag.id,
          ]
        );
      }

      totalTagged += batch.length;
      const pct = Math.round((totalTagged / totalUntagged) * 100);
      process.stdout.write(
        `\r✅ Tagged: ${totalTagged}/${totalUntagged} (${pct}%) | Errors: ${totalErrors}`
      );
    } catch (err) {
      totalErrors += batch.length;
      console.error(`\n❌ Batch error: ${(err as Error).message}`);

      // Mark failed recipes with a fallback timestamp so they don't get
      // stuck in the untagged pool forever — can re-run with a reset script
      const ids = batch.map((r) => `'${r.id}'`).join(",");
      await pool.query(
        `UPDATE recipes SET tags_generated_at = NOW() WHERE id IN (${ids})`
      );
    }

    // Respect Gemini rate limits
    await new Promise((r) => setTimeout(r, DELAY_MS));
  }

  await pool.end();

  console.log(`\n\n🎉 Tagging complete!`);
  console.log(`   Tagged: ${totalTagged}`);
  console.log(`   Errors: ${totalErrors}`);
  console.log(`\nVerify results in Supabase:`);
  console.log(`  SELECT region_group, COUNT(*) FROM recipes GROUP BY region_group;`);
  console.log(`  SELECT unnest(dietary_tags), COUNT(*) FROM recipes GROUP BY 1;`);
}

tagRecipesBatch().catch((err) => {
  console.error("Fatal error:", err);
  pool.end();
  process.exit(1);
});
