// =============================================================================
// NutriNext ParivarSehat — One Base, Many Plates Engine
// server/lib/oneManyPlates.ts
//
// PURPOSE:
//   Deterministically computes per-member plate modifications for every meal
//   slot BEFORE Gemini Call 2 runs. Gemini receives pre-computed modification
//   strings and formats them — it never invents clinical decisions.
//
// ZERO AI CALLS. Pure TypeScript. Runs in < 100ms for any family size.
//
// POSITION IN PIPELINE:
//   Conflict Engine → [THIS FILE] → Gemini Call 2 (Scheduler)
//
// HOW IT PLUGS IN:
//   In prompt-chain.ts → generateWeeklyMealPlan(), call buildMemberModifierMap()
//   before constructing the Gemini prompt. Pass the result to
//   buildModifierInjectionSection() and inject into the prompt.
// =============================================================================

import type {
  ConstraintPacket,
  EffectiveMemberProfile,
  MedicationGuardrailBundle,
  MedicationSlotConstraint,
} from "./types";

// =============================================================================
// EXPORTED INTERFACES
// =============================================================================

export interface ComputedMemberPlate {
  member_id: string;
  member_name: string;
  /** Ready-to-inject strings. Gemini formats these — never invents them. */
  modifications: string[];
  /** If not null, this member's portion must leave the pot BEFORE step N executes. */
  pull_before_step: number | null;
  pull_before_reason: string | null;
  pull_before_urgency: "CRITICAL" | "RECOMMENDED" | null;
  /** Ingredients added only to this member's plate after base dish is served. */
  additives: string[];
  /** Ingredients in the base dish that must NOT appear on this member's plate. */
  withheld: string[];
  /** Per-meal macro targets for this member × slot weight. */
  macro_targets: {
    calories: number;
    protein_g: number;
    carbs_g: number;
    fat_g: number;
    sodium_mg_max: number | null;
  };
  /** Clinical warnings surfaced in the recipe UI as ⚠️ flags. */
  clinical_flags: string[];
  /** Harmony score impact from this member's plate operation. */
  harmony_deduction_points: number;
  harmony_deduction_reason: string | null;
  harmony_addition_points: number;
  harmony_addition_reason: string | null;
}

export interface OneManyPlatesOutput {
  slot: "breakfast" | "lunch" | "dinner" | "snack";
  /** false = conflict escalation required; no single base dish serves everyone. */
  base_dish_is_valid: boolean;
  parallel_dishes_needed: number;
  escalation_reason: string | null;
  escalation_solution: string | null;
  member_plates: ComputedMemberPlate[];
  total_harmony_deduction: number;
  total_harmony_addition: number;
}

/** Key: "day0_breakfast", "day1_lunch", ..., "day6_dinner" */
export type MemberModifierMap = Map<string, OneManyPlatesOutput>;

// =============================================================================
// STATIC KNOWLEDGE TABLES
// These live here (not imported) to keep this file self-contained.
// They mirror the clinical rules in conflict-engine.ts and medicationRules.ts
// but are expressed as modifier-generation logic, not conflict-detection logic.
// =============================================================================

/** Ingredients that trigger a PULL_BEFORE event for specific dietary rules. */
const PULL_BEFORE_TRIGGERS: Record<string, {
  ingredients: string[];
  typicalStep: number; // approximate cooking step where ingredient is added
  reason: string;
  urgency: "CRITICAL" | "RECOMMENDED";
}> = {
  jain_rules: {
    ingredients: ["onion", "pyaz", "kanda", "garlic", "lehsun", "leek", "shallot", "spring onion"],
    typicalStep: 3,
    reason: "Jain dietary rule — no alliums. Pull portion before onion/garlic tempering.",
    urgency: "CRITICAL",
  },
  sattvic_no_onion_garlic: {
    ingredients: ["onion", "garlic", "leek", "shallot", "spring onion", "chive"],
    typicalStep: 3,
    reason: "Sattvic diet — no onion or garlic. Pull portion before tempering.",
    urgency: "CRITICAL",
  },
  dairy_allergy: {
    ingredients: ["ghee", "butter", "cream", "milk", "malai", "paneer", "curd", "dahi", "cheese"],
    typicalStep: 4,
    reason: "Dairy allergy. Pull portion before any dairy is added to the pot.",
    urgency: "CRITICAL",
  },
  hypertension_salt: {
    ingredients: ["salt", "namak"],
    typicalStep: 7,
    reason: "Hypertension. Pull portion before final salting. Season separately with minimal salt + lemon.",
    urgency: "RECOMMENDED",
  },
};

/** Condition → quantity modifiers on specific ingredients. */
const CONDITION_QUANTITY_MODIFIERS: Record<string, Array<{
  ingredient: string;
  multiplier: number; // 0 = withhold entirely, 0.5 = halve, 1.5 = increase
  unit_note: string;  // human-readable e.g. "150g instead of 250g"
  clinical_reason: string;
}>> = {
  diabetes_type_2: [
    { ingredient: "white rice / chawal", multiplier: 0.6, unit_note: "150g cooked instead of 250g", clinical_reason: "Low-GI mandate — reduce refined carbs" },
    { ingredient: "roti / chapati", multiplier: 0.75, unit_note: "1–2 instead of 3, prefer jowar/bajra roti", clinical_reason: "Lower glycaemic load" },
    { ingredient: "sugar / jaggery", multiplier: 0, unit_note: "omit entirely", clinical_reason: "T2D — no added sugar" },
    { ingredient: "ghee", multiplier: 0.5, unit_note: "½ tsp instead of 1 tsp", clinical_reason: "Fat moderation for metabolic health" },
    { ingredient: "potato / aloo", multiplier: 0.5, unit_note: "half portion if used in base", clinical_reason: "High GI — limit starchy vegetables" },
  ],
  hypertension: [
    { ingredient: "salt / namak", multiplier: 0.5, unit_note: "half the recipe quantity", clinical_reason: "Sodium cap ≤1500mg/day" },
    { ingredient: "ghee", multiplier: 0.5, unit_note: "½ tsp max", clinical_reason: "Cardiovascular protection" },
    { ingredient: "papad", multiplier: 0, unit_note: "withhold entirely (400–600mg sodium per piece)", clinical_reason: "Sodium cap" },
    { ingredient: "pickle / achar", multiplier: 0, unit_note: "withhold entirely", clinical_reason: "Sodium cap" },
  ],
  high_cholesterol: [
    { ingredient: "ghee", multiplier: 0.25, unit_note: "¼ tsp max", clinical_reason: "Saturated fat limit for cholesterol management" },
    { ingredient: "butter", multiplier: 0, unit_note: "omit — use olive oil or mustard oil instead", clinical_reason: "Trans/saturated fat elimination" },
    { ingredient: "full-fat dairy", multiplier: 0.5, unit_note: "use low-fat alternatives where possible", clinical_reason: "LDL reduction" },
  ],
  obesity: [
    { ingredient: "oil", multiplier: 0.5, unit_note: "half the recipe quantity", clinical_reason: "Calorie density reduction" },
    { ingredient: "rice", multiplier: 0.5, unit_note: "half portion", clinical_reason: "Calorie deficit target" },
    { ingredient: "ghee", multiplier: 0, unit_note: "omit — dry-cook or steam", clinical_reason: "Calorie reduction" },
  ],
  kidney_issues: [
    { ingredient: "salt / namak", multiplier: 0.4, unit_note: "less than half recipe quantity", clinical_reason: "Sodium cap ≤1200mg/day — CKD protocol" },
    { ingredient: "potato / aloo", multiplier: 0.3, unit_note: "minimal, boil and discard water (removes potassium)", clinical_reason: "Potassium restriction" },
    { ingredient: "tomato", multiplier: 0.3, unit_note: "minimal quantity", clinical_reason: "Potassium restriction" },
    { ingredient: "dairy", multiplier: 0.3, unit_note: "minimal", clinical_reason: "Phosphorus restriction" },
    { ingredient: "papad", multiplier: 0, unit_note: "withhold entirely", clinical_reason: "Sodium and phosphorus — CKD hard block" },
    { ingredient: "nuts", multiplier: 0, unit_note: "withhold", clinical_reason: "High phosphorus — CKD restriction" },
  ],
  pcos: [
    { ingredient: "white rice / chawal", multiplier: 0.6, unit_note: "150g cooked; prefer brown rice or millets", clinical_reason: "Insulin resistance — low GI mandate" },
    { ingredient: "maida / refined flour", multiplier: 0, unit_note: "omit entirely", clinical_reason: "Insulin spike avoidance" },
    { ingredient: "sugar", multiplier: 0, unit_note: "omit", clinical_reason: "PCOS insulin regulation" },
  ],
  hypothyroid: [
    { ingredient: "cabbage", multiplier: 0.3, unit_note: "minimal, always cooked (never raw)", clinical_reason: "Goitrogenic vegetable — cooking reduces interference" },
    { ingredient: "cauliflower / gobi", multiplier: 0.3, unit_note: "minimal, always cooked", clinical_reason: "Goitrogenic — limit near medication time" },
    { ingredient: "broccoli", multiplier: 0.3, unit_note: "minimal, always cooked", clinical_reason: "Goitrogenic" },
    { ingredient: "soy", multiplier: 0, unit_note: "omit from hypothyroid member's plate", clinical_reason: "Soy interferes with levothyroxine absorption" },
  ],
};

/** Condition/goal → additives for specific members' plates. */
const ADDITIVE_RULES: Record<string, Array<{
  additive: string;
  instruction: string;
}>> = {
  anaemia: [
    { additive: "lemon juice / nimbu", instruction: "Squeeze lemon on plate — Vitamin C enhances iron absorption by 2–3×" },
    { additive: "til / sesame seeds", instruction: "Sprinkle 1 tsp til on plate — iron source (7.8mg/100g)" },
  ],
  build_muscle: [
    { additive: "extra dal scoop", instruction: "Add extra 100ml dal on side — protein boost (+6g protein)" },
    { additive: "egg / anda (if non-veg permitted)", instruction: "Add 1 boiled egg on side if dietary type permits — 6g protein" },
  ],
  weight_gain: [
    { additive: "extra ghee (½ tsp)", instruction: "Add ½ tsp ghee on rice/roti — calorie surplus support" },
    { additive: "extra roti", instruction: "Add 1 extra roti — calorie surplus" },
  ],
  high_cholesterol: [
    { additive: "flaxseed / alsi (ground, ½ tsp)", instruction: "Add ½ tsp ground flaxseed — omega-3 for cholesterol management" },
  ],
  pcos: [
    { additive: "flaxseed / alsi (ground, ½ tsp)", instruction: "Add ½ tsp ground flaxseed — omega-3, anti-inflammatory for PCOS" },
    { additive: "turmeric pinch (extra)", instruction: "Extra pinch of turmeric — anti-inflammatory" },
  ],
  diabetes_type_2: [
    { additive: "fenugreek seeds / methi (soaked, ½ tsp on side)", instruction: "Add soaked methi on side if available — proven blood sugar regulation effect (ICMR-NIN 2024)" },
  ],
};

/** Macro targets by sodium cap condition. */
const SODIUM_CAPS_BY_CONDITION: Record<string, number> = {
  hypertension: 1500,
  kidney_issues: 1200,
};

/** Slot weights for splitting daily calorie target across meals. */
const DEFAULT_SLOT_WEIGHTS = {
  breakfast: 0.28,
  lunch: 0.36,
  dinner: 0.36,
  snack: 0.08,
};

// =============================================================================
// STEP A — HARD BLOCK DETECTION
// Returns modification strings for all hard blocks (allergy, religious, medication).
// Also returns withheld[] and the pull-before info.
// =============================================================================

function computeHardBlockModifications(
  profile: EffectiveMemberProfile,
  slot: "breakfast" | "lunch" | "dinner" | "snack",
  medBundles: MedicationGuardrailBundle[]
): {
  modifications: string[];
  withheld: string[];
  pull_before_step: number | null;
  pull_before_reason: string | null;
  pull_before_urgency: "CRITICAL" | "RECOMMENDED" | null;
  clinical_flags: string[];
  harmony_deduction_points: number;
  harmony_deduction_reason: string | null;
} {
  const modifications: string[] = [];
  const withheld: string[] = [];
  const clinical_flags: string[] = [];
  let pull_before_step: number | null = null;
  let pull_before_reason: string | null = null;
  let pull_before_urgency: "CRITICAL" | "RECOMMENDED" | null = null;
  let harmony_deduction_points = 0;
  let harmony_deduction_reason: string | null = null;

  // ── 1. Allergy blocks ──────────────────────────────────────────────────────

  for (const allergy of profile.allergies) {
    if (allergy === "none") continue;

    // Dairy allergy is special — needs a pull-before event
    if (allergy === "dairy") {
      const trigger = PULL_BEFORE_TRIGGERS.dairy_allergy;
      pull_before_step = trigger.typicalStep;
      pull_before_reason = trigger.reason;
      pull_before_urgency = trigger.urgency;
      modifications.push(
        `ALLERGY CRITICAL — ${profile.name}: Pull portion before any dairy (ghee/paneer/curd/butter) is added. ` +
        `Do NOT use ghee to finish ${profile.name}'s plate. Use cooking oil (mustard/sunflower) instead.`
      );
      withheld.push("ghee", "paneer", "curd", "butter", "cream", "milk", "malai");
      clinical_flags.push(`⚠️ DAIRY ALLERGY: Any dairy in ${profile.name}'s plate is a medical emergency.`);
      harmony_deduction_points -= 2; // resolved via plate modification — -2 points
      harmony_deduction_reason = `Dairy allergy — plate modification required for ${profile.name}`;
    } else {
      const allergyLabel: Record<string, string> = {
        peanuts: "peanuts / groundnuts / mungfali",
        gluten: "wheat / atta / maida / roti / chapati (SERVE GLUTEN-FREE ALTERNATIVE: rice, jowar, bajra, kuttu)",
        tree_nuts: "almonds / cashews / walnuts / pistachios",
        shellfish: "prawns / shrimp / crab / lobster",
        soy: "soya chunks / tofu / soy sauce",
        sesame: "til / sesame seeds / gingelly oil",
      };
      const label = allergyLabel[allergy] ?? allergy;
      modifications.push(`ALLERGY CRITICAL — ${profile.name}: NO ${label} anywhere in this plate.`);
      withheld.push(allergy);
      clinical_flags.push(`⚠️ ALLERGY: ${profile.name} — ${allergy} is a hard block.`);
    }
  }

  // ── 2. Religious / cultural rule blocks ───────────────────────────────────

  const relType = profile.religiousCulturalRules?.type ?? "none";

  if (relType === "jain_rules") {
    const trigger = PULL_BEFORE_TRIGGERS.jain_rules;
    pull_before_step = Math.min(pull_before_step ?? trigger.typicalStep, trigger.typicalStep);
    pull_before_reason = trigger.reason;
    pull_before_urgency = "CRITICAL";
    modifications.push(
      `JAIN RULE — ${profile.name}: Pull portion before onion, garlic, and all root vegetables ` +
      `(potato, carrot, radish, beetroot, turnip, arbi) are added. ` +
      `No onion/garlic at any point in ${profile.name}'s preparation.`
    );
    withheld.push("onion", "garlic", "potato", "carrot", "radish", "beetroot", "turnip", "arbi", "sweet potato");
    harmony_deduction_points -= 2;
    harmony_deduction_reason = `Jain rule — plate modification required for ${profile.name}`;
  }

  if (relType === "sattvic_no_onion_garlic") {
    const trigger = PULL_BEFORE_TRIGGERS.sattvic_no_onion_garlic;
    pull_before_step = Math.min(pull_before_step ?? trigger.typicalStep, trigger.typicalStep);
    pull_before_reason = trigger.reason;
    pull_before_urgency = "CRITICAL";
    modifications.push(
      `SATTVIC RULE — ${profile.name}: NO onion or garlic. ` +
      `Pull portion before tempering (tadka) with onion/garlic. ` +
      `Use asafoetida (hing) and ginger for flavour in ${profile.name}'s portion.`
    );
    withheld.push("onion", "garlic", "leek", "shallot", "chive");
  }

  if (relType === "no_beef") {
    modifications.push(`RELIGIOUS — ${profile.name}: Absolutely no beef or veal in any form.`);
    withheld.push("beef", "veal");
  }

  if (relType === "no_pork") {
    modifications.push(`RELIGIOUS — ${profile.name}: Absolutely no pork, bacon, ham, or lard.`);
    withheld.push("pork", "bacon", "ham", "lard");
  }

  // ── 3. Medication slot constraints (Level 3) ──────────────────────────────

  const memberBundles = medBundles.filter((b) => b.member_name === profile.name);

  for (const bundle of memberBundles) {
    for (const directive of bundle.directives) {
      // Filter to directives relevant to this slot
      if (
        directive.toLowerCase().includes(slot) ||
        directive.toLowerCase().includes("all meals") ||
        directive.toLowerCase().includes("every meal")
      ) {
        modifications.push(`MEDICATION — ${profile.name}: ${directive}`);
      }
    }
    // Add forbidden ingredients from slot constraints
    for (const sc of (bundle as any).slot_constraints ?? []) {
      const constraint = sc as MedicationSlotConstraint;
      if (constraint.slot === slot || constraint.slot === "all") {
        withheld.push(...constraint.forbidden_ingredients);
        if (constraint.must_have_solid_food) {
          modifications.push(
            `MEDICATION TIMING — ${profile.name}: This meal slot MUST contain solid food ` +
            `(not just tea/juice). Medication requires food to be present.`
          );
        }
      }
    }
  }

  // ── 4. Hypertension pull-before for salt ─────────────────────────────────

  if (
    profile.effectiveHealthConditions.includes("hypertension") &&
    pull_before_step === null
  ) {
    const trigger = PULL_BEFORE_TRIGGERS.hypertension_salt;
    pull_before_step = trigger.typicalStep;
    pull_before_reason = trigger.reason;
    pull_before_urgency = "RECOMMENDED";
    modifications.push(
      `HYPERTENSION — ${profile.name}: Pull portion before final salting. ` +
      `Season ${profile.name}'s plate separately: use ¼ tsp salt max + lemon juice + amchur for flavour. ` +
      `Others add their own salt at the table.`
    );
  }

  return {
    modifications,
    withheld: [...new Set(withheld)],
    pull_before_step,
    pull_before_reason,
    pull_before_urgency,
    clinical_flags,
    harmony_deduction_points,
    harmony_deduction_reason,
  };
}

// =============================================================================
// STEP B — SOFT BLOCK (QUANTITY) MODIFICATIONS
// =============================================================================

function computeQuantityModifications(
  profile: EffectiveMemberProfile,
  slot: "breakfast" | "lunch" | "dinner" | "snack"
): string[] {
  const modifications: string[] = [];

  for (const condition of profile.effectiveHealthConditions) {
    if (condition === "none") continue;
    const rules = CONDITION_QUANTITY_MODIFIERS[condition] ?? [];
    for (const rule of rules) {
      if (rule.multiplier === 0) {
        modifications.push(
          `${condition.toUpperCase().replace(/_/g, " ")} — ${profile.name}: ` +
          `WITHHOLD ${rule.ingredient} (${rule.unit_note}). Reason: ${rule.clinical_reason}`
        );
      } else {
        modifications.push(
          `${condition.toUpperCase().replace(/_/g, " ")} — ${profile.name}: ` +
          `Reduce ${rule.ingredient} to ${rule.unit_note}. Reason: ${rule.clinical_reason}`
        );
      }
    }
  }

  // Ingredient dislikes (Level 6 — lowest priority, just a note)
  for (const dislike of profile.ingredientDislikes) {
    modifications.push(
      `PREFERENCE — ${profile.name}: Avoid or minimise ${dislike} if possible (user preference).`
    );
  }

  // Spice tolerance
  if (profile.effectiveSpiceTolerance === "mild") {
    modifications.push(
      `SPICE — ${profile.name}: Mild spice only. Half the chilli/green chilli called for in recipe.`
    );
  }

  // Child texture (under 5)
  if (profile.isChildUnder5) {
    modifications.push(
      `INFANT — ${profile.name} (under 5): Blend or mash portion to smooth consistency. ` +
      `Zero chilli. No whole nuts or hard seeds. Serve at safe temperature.`
    );
  }

  // Child portion (school age)
  if (profile.isSchoolAge) {
    modifications.push(
      `CHILD PORTION — ${profile.name}: 60–70% of adult portion size. ` +
      `Mild spice. Ensure adequate protein and calcium for growth.`
    );
  }

  return modifications;
}

// =============================================================================
// STEP C — ADDITIVE COMPUTATION
// =============================================================================

function computeAdditives(
  profile: EffectiveMemberProfile,
  slot: "breakfast" | "lunch" | "dinner" | "snack"
): string[] {
  const additives: string[] = [];

  // Condition-based additives
  for (const condition of profile.effectiveHealthConditions) {
    const rules = ADDITIVE_RULES[condition] ?? [];
    for (const rule of rules) {
      additives.push(`${rule.additive} — ${rule.instruction}`);
    }
  }

  // Goal-based additives
  if (profile.effectiveGoal === "build_muscle") {
    const rules = ADDITIVE_RULES.build_muscle ?? [];
    for (const rule of rules) {
      additives.push(`${rule.additive} — ${rule.instruction}`);
    }
  }

  if (profile.effectiveGoal === "weight_gain") {
    const rules = ADDITIVE_RULES.weight_gain ?? [];
    for (const rule of rules) {
      additives.push(`${rule.additive} — ${rule.instruction}`);
    }
  }

  // Senior nutritional bandaid
  if (profile.isSenior) {
    additives.push(
      "makhana / fox nuts (small portion, 10–15 pieces on side) — " +
      "calorie-dense, phosphorus-controlled senior snack to maintain 1400+ kcal/day"
    );
  }

  return [...new Set(additives)];
}

// =============================================================================
// STEP D — FASTING REPLACEMENT
// =============================================================================

function computeFastingReplacement(
  profile: EffectiveMemberProfile,
  slot: "breakfast" | "lunch" | "dinner" | "snack",
  activeFestival: string | null,
  weekday: string
): string | null {
  const isFastingToday = profile.effectiveFastingDays
    .map((d) => d.toLowerCase())
    .includes(weekday.toLowerCase());

  if (!isFastingToday) return null;

  if (activeFestival === "Navratri") {
    const diabeticWarning = profile.effectiveHealthConditions.includes("diabetes_type_2")
      ? " ⚠️ DIABETES + NAVRATRI FASTING: Sabudana is high GI (70) — limit to 80g cooked. " +
        "Prefer kuttu roti or rajgira khichdi for lower glycaemic impact. " +
        "Add peanuts (if allowed) to slow glucose absorption."
      : "";

    const NAVRATRI_SUGGESTIONS: Record<string, string> = {
      breakfast: "Kuttu ka dosa OR Rajgira porridge with sendha namak OR Sabudana khichdi (80g max for diabetics)",
      lunch: "Aloo sabzi with kuttu roti OR Singhare ki puri OR Samak rice khichdi",
      dinner: "Sabudana khichdi OR Kuttu ki poori with aloo subzi OR Makhana kheer (dairy-free for allergic)",
      snack: "Fruits OR Makhana (fox nuts, roasted with sendha namak) OR Dry fruits",
    };

    return `NAVRATRI FASTING — ${profile.name}: Replace ${slot} with: ${NAVRATRI_SUGGESTIONS[slot]}.${diabeticWarning}`;
  }

  if (activeFestival === "Ekadashi") {
    return (
      `EKADASHI FASTING — ${profile.name}: Replace ${slot} with fruits, milk (if no dairy allergy), ` +
      `nuts, and root vegetables only. No grains or beans on Ekadashi.`
    );
  }

  // Regular weekly fasting day (non-festival)
  if (profile.effectiveHealthConditions.includes("anaemia")) {
    return (
      `WEEKLY FAST — ${profile.name} (anaemic): Ensure iron-rich fasting foods: ` +
      `rajgira (amaranth) rotis, singhare ka atta, dates, jaggery in small quantity. ` +
      `⚠️ ANAEMIA ALERT: Iron intake must not drop below 12mg on fasting days. Supplement with amla chutney.`
    );
  }

  return (
    `FASTING DAY — ${profile.name}: Replace with light, appropriate meal per their fasting rules. ` +
    `Ensure minimum calorie intake of ${Math.round(profile.dailyCalorieTarget * 0.7)} kcal for this day.`
  );
}

// =============================================================================
// STEP E — CONFLICT ESCALATION DETECTION
// =============================================================================

function detectConflictEscalation(
  profiles: EffectiveMemberProfile[]
): {
  needs_escalation: boolean;
  reason: string | null;
  solution: string | null;
  affected_members: string[];
} {
  // Non-veg base dish + strictly vegetarian member
  const nonvegMembers = profiles.filter(
    (p) => p.dietaryType === "non_vegetarian" || p.dietaryType === "eggetarian"
  );
  const strictVegMembers = profiles.filter(
    (p) =>
      p.dietaryType === "strictly_vegetarian" ||
      p.dietaryType === "jain_vegetarian"
  );

  if (nonvegMembers.length > 0 && strictVegMembers.length > 0) {
    const vegNames = strictVegMembers.map((p) => p.name).join(", ");
    const nonvegNames = nonvegMembers.map((p) => p.name).join(", ");
    return {
      needs_escalation: true,
      reason:
        `Mixed household conflict: ${nonvegNames} require non-vegetarian meals; ` +
        `${vegNames} are strictly vegetarian. No single base dish can serve both.`,
      solution:
        `SOLUTION: Prepare 2 parallel tracks. ` +
        `Track A (Vegetarian): ${vegNames} — vegetarian base dish (e.g. dal/sabzi/paneer). ` +
        `Track B (Non-vegetarian): ${nonvegNames} — same vegetarian base + non-veg protein addition ` +
        `(cooked in separate vessel). Shared rice/roti acceptable. ` +
        `Use same spice base; cook vegetarian first, then add non-veg separately.`,
      affected_members: [...strictVegMembers.map((p) => p.name), ...nonvegMembers.map((p) => p.name)],
    };
  }

  // Jain member + fundamentally incompatible base dish signal
  const jainMembers = profiles.filter((p) => p.dietaryType === "jain_vegetarian");
  const nonJainMembers = profiles.filter((p) => p.dietaryType !== "jain_vegetarian");

  if (jainMembers.length > 0 && nonJainMembers.length > 0) {
    // This only escalates if the base dish is fundamentally incompatible.
    // In most cases, a pull-before handles it. We flag it as a potential escalation
    // to alert Gemini to select a dish where pull-before is feasible.
    // We do NOT force escalation here — Gemini must try pull-before first.
    // Escalation only fires if the dish cannot be modified (handled below).
    // For now, flag a soft warning — not an escalation.
  }

  return { needs_escalation: false, reason: null, solution: null, affected_members: [] };
}

// =============================================================================
// STEP F — MACRO TARGET COMPUTATION
// =============================================================================

function computeMacroTargets(
  profile: EffectiveMemberProfile,
  slot: "breakfast" | "lunch" | "dinner" | "snack",
  slotWeights: { breakfast: number; lunch: number; dinner: number }
): ComputedMemberPlate["macro_targets"] {
  const weight = (slotWeights as any)[slot] ?? DEFAULT_SLOT_WEIGHTS[slot] ?? 0.28;
  const targetCalories = Math.round(profile.dailyCalorieTarget * weight);

  // Carb ratio: diabetes → 40%, default → 55%
  const carbRatio = profile.effectiveHealthConditions.includes("diabetes_type_2") ? 0.40 : 0.55;
  const proteinRatio = profile.effectiveGoal === "build_muscle" ? 0.30 : 0.20;
  const fatRatio = 1 - carbRatio - proteinRatio;

  const carbsG = Math.round((targetCalories * carbRatio) / 4);
  const proteinG = Math.round((targetCalories * proteinRatio) / 4);
  const fatG = Math.round((targetCalories * fatRatio) / 9);

  // Sodium cap: use strictest condition that applies
  let sodiumCapDay: number | null = null;
  for (const condition of profile.effectiveHealthConditions) {
    const cap = SODIUM_CAPS_BY_CONDITION[condition];
    if (cap !== undefined) {
      sodiumCapDay = sodiumCapDay === null ? cap : Math.min(sodiumCapDay, cap);
    }
  }
  const sodiumCapSlot = sodiumCapDay !== null ? Math.round(sodiumCapDay * weight) : null;

  return {
    calories: targetCalories,
    protein_g: proteinG,
    carbs_g: carbsG,
    fat_g: fatG,
    sodium_mg_max: sodiumCapSlot,
  };
}

// =============================================================================
// MAIN EXPORT: buildMemberModifierMap
// =============================================================================

/**
 * Builds a complete map of per-member plate modifications for every meal slot
 * across the 7-day week. This is called ONCE before Gemini Call 2.
 *
 * The output is injected into the Gemini prompt so Gemini receives pre-computed
 * modification strings and formats them — it never invents clinical decisions.
 *
 * @param packet - Full ConstraintPacket from runConflictEngine()
 * @param slotWeights - Budget weight per slot (from budget.budgetBreakdown)
 */
export function buildMemberModifierMap(
  packet: ConstraintPacket,
  slotWeights: { breakfast: number; lunch: number; dinner: number }
): MemberModifierMap {
  const map: MemberModifierMap = new Map();
  const slots: Array<"breakfast" | "lunch" | "dinner"> = ["breakfast", "lunch", "dinner"];
  const WEEKDAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

  const escalation = detectConflictEscalation(packet.effectiveProfiles);

  for (let dayIndex = 0; dayIndex < 7; dayIndex++) {
    const weekday = WEEKDAYS[dayIndex];
    const activeFestival = packet.weeklyContext.activeFestival as string | null ?? null;

    for (const slot of slots) {
      const memberPlates: ComputedMemberPlate[] = [];
      let totalDeduction = 0;
      let totalAddition = 0;

      for (const profile of packet.effectiveProfiles) {
        // ── Check fasting first (overrides everything) ──────────────────────
        const fastingReplacement = computeFastingReplacement(
          profile, slot, activeFestival, weekday
        );

        if (fastingReplacement) {
          memberPlates.push({
            member_id: profile.id,
            member_name: profile.name,
            modifications: [fastingReplacement],
            pull_before_step: null,
            pull_before_reason: null,
            pull_before_urgency: null,
            additives: [],
            withheld: [],
            macro_targets: computeMacroTargets(profile, slot, slotWeights),
            clinical_flags: [`FASTING DAY: ${profile.name} is fasting — meal replaced.`],
            harmony_deduction_points: 0,
            harmony_deduction_reason: null,
            harmony_addition_points: 0,
            harmony_addition_reason: null,
          });
          continue;
        }

        // ── Step A: Hard block modifications ────────────────────────────────
        const hardBlocks = computeHardBlockModifications(
          profile,
          slot,
          packet.medicationGuardrailBundles
        );

        // ── Step B: Soft block / quantity modifications ──────────────────────
        const quantityMods = computeQuantityModifications(profile, slot);

        // ── Step C: Additives ────────────────────────────────────────────────
        const additives = computeAdditives(profile, slot);

        // ── Step F: Macro targets ────────────────────────────────────────────
        const macroTargets = computeMacroTargets(profile, slot, slotWeights);

        // ── Clinical flags for macro constraints ─────────────────────────────
        const macroFlags: string[] = [];
        if (macroTargets.sodium_mg_max !== null) {
          macroFlags.push(
            `SODIUM CAP: ${profile.name}'s plate must not exceed ${macroTargets.sodium_mg_max}mg sodium in this ${slot}.`
          );
        }
        if (profile.effectiveGoal === "build_muscle" && slot !== "breakfast") {
          macroFlags.push(
            `HIGH PROTEIN: ${profile.name} needs ${macroTargets.protein_g}g+ protein at this meal.`
          );
        }

        // ── Harmony tracking ─────────────────────────────────────────────────
        let additionPoints = 0;
        let additionReason: string | null = null;
        if (
          hardBlocks.pull_before_step !== null ||
          hardBlocks.modifications.length > 0
        ) {
          // Plate modification used to resolve conflict → -2 points
          // (vs base dish change → -5 points, which happens in escalation)
          // Already counted in hardBlocks.harmony_deduction_points
        }

        // Correctly handled medication window → +3 per bundle
        const memberBundles = packet.medicationGuardrailBundles.filter(
          (b) => b.member_name === profile.name
        );
        if (memberBundles.length > 0) {
          additionPoints = memberBundles.reduce(
            (sum, b) => sum + (b.harmony_score_addition ?? 0),
            0
          );
          additionReason = `Correctly scheduled medication windows for ${profile.name}`;
        }

        totalDeduction += hardBlocks.harmony_deduction_points;
        totalAddition += additionPoints;

        memberPlates.push({
          member_id: profile.id,
          member_name: profile.name,
          modifications: [...hardBlocks.modifications, ...quantityMods],
          pull_before_step: hardBlocks.pull_before_step,
          pull_before_reason: hardBlocks.pull_before_reason,
          pull_before_urgency: hardBlocks.pull_before_urgency,
          additives,
          withheld: hardBlocks.withheld,
          macro_targets: macroTargets,
          clinical_flags: [...hardBlocks.clinical_flags, ...macroFlags],
          harmony_deduction_points: hardBlocks.harmony_deduction_points,
          harmony_deduction_reason: hardBlocks.harmony_deduction_reason,
          harmony_addition_points: additionPoints,
          harmony_addition_reason: additionReason,
        });
      }

      const key = `day${dayIndex}_${slot}`;
      map.set(key, {
        slot,
        base_dish_is_valid: !escalation.needs_escalation,
        parallel_dishes_needed: escalation.needs_escalation ? 2 : 1,
        escalation_reason: escalation.needs_escalation ? escalation.reason : null,
        escalation_solution: escalation.needs_escalation ? escalation.solution : null,
        member_plates: memberPlates,
        total_harmony_deduction: totalDeduction,
        total_harmony_addition: totalAddition,
      });
    }
  }

  return map;
}

// =============================================================================
// PROMPT INJECTION HELPER
// Call this in prompt-chain.ts → generateWeeklyMealPlan() to inject the
// pre-computed modifiers into the Gemini prompt.
// =============================================================================

/**
 * Converts the MemberModifierMap into a prompt string section that Gemini
 * receives verbatim. Gemini reads these and formats them into member_plates[]
 * in its JSON output — it does NOT invent any modifications.
 */
export function buildModifierInjectionSection(map: MemberModifierMap): string {
  const lines: string[] = [
    "═══════════════════════════════════════════════════════════════",
    "PRE-COMPUTED PLATE MODIFICATIONS — READ CAREFULLY BEFORE GENERATING ANY MEAL",
    "These were computed deterministically by the clinical engine.",
    "YOUR ONLY JOB is to pick appropriate recipes and format these strings into",
    "the member_plates[].modifications array in your JSON output.",
    "DO NOT change, omit, or supplement these with your own clinical reasoning.",
    "DO NOT add any medical or dietary modifications not listed here.",
    "═══════════════════════════════════════════════════════════════",
    "",
  ];

  // Group by day for readability
  for (let day = 0; day < 7; day++) {
    const WEEKDAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
    lines.push(`── DAY ${day + 1} (${WEEKDAYS[day]}) ─────────────────────────────────`);

    for (const slot of ["breakfast", "lunch", "dinner"] as const) {
      const key = `day${day}_${slot}`;
      const output = map.get(key);
      if (!output) continue;

      lines.push(`  ${slot.toUpperCase()}:`);

      if (!output.base_dish_is_valid) {
        lines.push(`    ⚠️  CONFLICT ESCALATION — 2 PARALLEL DISHES REQUIRED`);
        lines.push(`    REASON: ${output.escalation_reason}`);
        lines.push(`    SOLUTION: ${output.escalation_solution}`);
        lines.push(`    Set parallel_dish: true on conflicted member's plate.`);
        lines.push(`    HARMONY: -5 points (unresolvable base dish conflict)`);
      }

      for (const plate of output.member_plates) {
        if (plate.modifications.length === 0 && plate.additives.length === 0) {
          lines.push(`    ${plate.member_name}: No modifications — standard full portion.`);
          continue;
        }

        lines.push(`    ${plate.member_name} [${plate.member_id}]:`);

        for (const mod of plate.modifications) {
          lines.push(`      • ${mod}`);
        }

        if (plate.additives.length > 0) {
          lines.push(`      ➕ ADDITIVES: ${plate.additives.join(" | ")}`);
        }

        if (plate.pull_before_step !== null) {
          lines.push(
            `      ⏱️  [${plate.pull_before_urgency}] PULL BEFORE COOKING STEP ${plate.pull_before_step}: ${plate.pull_before_reason}`
          );
        }

        if (plate.clinical_flags.length > 0) {
          for (const flag of plate.clinical_flags) {
            lines.push(`      ${flag}`);
          }
        }

        lines.push(
          `      MACRO TARGET: ${plate.macro_targets.calories} kcal | ` +
          `${plate.macro_targets.protein_g}g protein | ${plate.macro_targets.carbs_g}g carbs | ` +
          `${plate.macro_targets.fat_g}g fat` +
          (plate.macro_targets.sodium_mg_max
            ? ` | max ${plate.macro_targets.sodium_mg_max}mg sodium`
            : "")
        );
      }

      lines.push("");
    }
  }

  lines.push("═══════════════════════════════════════════════════════════════");
  return lines.join("\n");
}
