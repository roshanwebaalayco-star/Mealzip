// =============================================================================
// NutriNext ParivarSehat — One Base Many Plates Test Harness
// server/lib/oneManyPlates.test.ts
//
// Run with: npx tsx server/lib/oneManyPlates.test.ts
//
// Builds minimal ConstraintPackets from inline test data.
// No DB connection required. No AI calls. Pure deterministic output.
// =============================================================================

import {
  buildMemberModifierMap,
  buildModifierInjectionSection,
  MemberModifierMap,
} from "./oneManyPlates";

import type {
  ConstraintPacket,
  EffectiveMemberProfile,
  Family,
  MonthlyBudget,
  WeeklyContext,
  HarmonyScoreBreakdown,
} from "./types";

// =============================================================================
// TEST HELPERS
// =============================================================================

let passCount = 0;
let failCount = 0;

function assert(condition: boolean, label: string): void {
  if (condition) {
    console.log(`  ✅ PASS: ${label}`);
    passCount++;
  } else {
    console.log(`  ❌ FAIL: ${label}`);
    failCount++;
  }
}

function buildMinimalPacket(
  members: Partial<EffectiveMemberProfile>[],
  activeFestival: string | null = null,
  medicationBundles: any[] = []
): ConstraintPacket {
  const defaultProfile: EffectiveMemberProfile = {
    id: "member-default",
    name: "Default",
    age: 30,
    gender: "male",
    heightCm: 170,
    effectiveWeightKg: 70,
    activityLevel: "lightly_active",
    displayOrder: 0,
    dietaryType: "strictly_vegetarian",
    religiousCulturalRules: { type: "none", details: [] },
    allergies: [],
    ingredientDislikes: [],
    occasionalNonvegConfig: null,
    effectiveGoal: "maintain",
    goalPace: null,
    effectiveHealthConditions: [],
    effectiveSpiceTolerance: "medium",
    effectiveFastingDays: [],
    ekadashiThisWeek: false,
    festivalFastThisWeek: activeFestival !== null,
    activeMedications: [],
    feelingThisWeek: null,
    nonvegDaysThisWeek: [],
    nonvegTypesThisWeek: [],
    tiffinNeeded: "no",
    dailyCalorieTarget: 2000,
    isChildUnder5: false,
    isSchoolAge: false,
    isTeen: false,
    isSenior: false,
  };

  const effectiveProfiles: EffectiveMemberProfile[] = members.map((m, i) => ({
    ...defaultProfile,
    id: `member-${i + 1}`,
    displayOrder: i,
    ...m,
    isChildUnder5: (m.age ?? 30) < 5,
    isSchoolAge: (m.age ?? 30) >= 5 && (m.age ?? 30) <= 12,
    isTeen: (m.age ?? 30) >= 13 && (m.age ?? 30) <= 17,
    isSenior: (m.age ?? 30) >= 60,
  }));

  const mockFamily: Family = {
    id: "family-test",
    userId: "user-test",
    name: "Test Family",
    stateRegion: "Delhi",
    languagePreference: "hindi",
    householdDietaryBaseline: "strictly_veg",
    mealsPerDay: "3_meals",
    cookingSkillLevel: "intermediate",
    appliances: ["gas_stove", "pressure_cooker"],
    pincode: "110001",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  } as any;

  const mockBudget: MonthlyBudget = {
    id: "budget-test",
    familyId: "family-test",
    monthYear: "2025-07",
    totalMonthlyBudget: 10000,
    staplesBudget: 4000,
    perishablesBudget: 5000,
    bufferBudget: 1000,
    dailyPerishableLimit: 166,
    regionalPriceSuggestion: 14850,
    budgetBreakdown: {
      breakfast_weight: 0.28,
      lunch_weight: 0.36,
      dinner_weight: 0.36,
      snack_weight: 0,
      daily_limits: { breakfast: 46, lunch: 60, dinner: 60, snack: 0 },
    },
    createdAt: new Date().toISOString(),
  } as any;

  const mockWeeklyContext: WeeklyContext = {
    id: "wc-test",
    familyId: "family-test",
    weekStartDate: "2025-07-07",
    eatingOutFrequency: "none",
    weekdayCookingTime: "20_40_mins",
    weekendCookingTime: "elaborate",
    weeklyPerishableBudgetOverride: null,
    pantrySnapshot: [],
    activeFestival,
    festivalFastingMemberIds: [],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  } as any;

  const mockHarmony: HarmonyScoreBreakdown = {
    base: 100,
    deductions: [],
    additions: [],
    conflicts_detected: [],
    conflicts_resolved: [],
    final_score: 100,
  };

  return {
    family: mockFamily,
    effectiveProfiles,
    budget: mockBudget,
    weeklyContext: mockWeeklyContext,
    harmonyScore: mockHarmony,
    conflicts: [],
    resolutions: [],
    pantryZeroWasteItems: [],
    fastingPreloadInstructions: [],
    medicationWarnings: [],
    medicationGuardrailBundles: medicationBundles,
    medicationWeeklyMonitorDirectives: [],
    medicationSchedulingNotes: [],
    medicationHarmonyAddition: 0,
    effectiveDailyBudget: 166,
    nonvegDaysByMember: {},
  };
}

// =============================================================================
// TEST 1 — Jain Grandmother + Diabetic Father + Muscle-building Son
// =============================================================================

console.log("\n");
console.log("═══════════════════════════════════════════════════════════════");
console.log("TEST 1 — Jain Grandmother + Diabetic Father + Muscle-building Son");
console.log("═══════════════════════════════════════════════════════════════");

const packet1 = buildMinimalPacket([
  {
    id: "member-1",
    name: "Ramesh",
    age: 52,
    gender: "male",
    effectiveWeightKg: 78,
    effectiveHealthConditions: ["diabetes_type_2"],
    dietaryType: "strictly_vegetarian",
    allergies: [],
    effectiveGoal: "manage_condition",
    dailyCalorieTarget: 1800,
  },
  {
    id: "member-2",
    name: "Sunita",
    age: 48,
    gender: "female",
    effectiveWeightKg: 62,
    effectiveHealthConditions: [],
    dietaryType: "strictly_vegetarian",
    allergies: [],
    effectiveGoal: "maintain",
    dailyCalorieTarget: 1600,
  },
  {
    id: "member-3",
    name: "Dadi",
    age: 74,
    gender: "female",
    effectiveWeightKg: 55,
    effectiveHealthConditions: ["hypertension"],
    dietaryType: "jain_vegetarian",
    religiousCulturalRules: { type: "jain_rules", details: [] },
    allergies: [],
    effectiveGoal: "senior_nutrition",
    dailyCalorieTarget: 1500,
    isSenior: true,
  },
  {
    id: "member-4",
    name: "Arjun",
    age: 19,
    gender: "male",
    effectiveWeightKg: 68,
    effectiveHealthConditions: [],
    dietaryType: "strictly_vegetarian",
    allergies: [],
    effectiveGoal: "build_muscle",
    dailyCalorieTarget: 2800,
  },
]);

const slotWeights = { breakfast: 0.28, lunch: 0.36, dinner: 0.36 };
const map1 = buildMemberModifierMap(packet1, slotWeights);

// Run assertions
console.log("\n── ASSERTIONS ──────────────────────────────────────────────────");

// Dadi must have pull_before_step !== null (Jain rule triggers pull-before)
const dadiDinnerDay0 = map1.get("day0_dinner");
const dadiPlate = dadiDinnerDay0?.member_plates.find((p) => p.member_name === "Dadi");
assert(dadiPlate !== undefined, "Dadi plate exists in day0_dinner");
assert(dadiPlate?.pull_before_step !== null, "Dadi has pull_before_step (Jain rule)");
assert(dadiPlate?.pull_before_urgency === "CRITICAL", "Dadi pull_before_urgency is CRITICAL");

// Ramesh must have at least one modification mentioning rice or portion
const rameshPlate = dadiDinnerDay0?.member_plates.find((p) => p.member_name === "Ramesh");
assert(rameshPlate !== undefined, "Ramesh plate exists");
const rameshHasDiabetesModification = rameshPlate?.modifications.some(
  (m) => m.toLowerCase().includes("rice") || m.toLowerCase().includes("150g") || m.toLowerCase().includes("diabetes")
);
assert(rameshHasDiabetesModification === true, "Ramesh has diabetes-related modification");

// Arjun must have additives (build_muscle)
const arjunPlate = dadiDinnerDay0?.member_plates.find((p) => p.member_name === "Arjun");
assert(arjunPlate !== undefined, "Arjun plate exists");
assert((arjunPlate?.additives.length ?? 0) > 0, "Arjun has additives (build_muscle goal)");

// No conflict escalation (all strictly vegetarian household)
assert(dadiDinnerDay0?.base_dish_is_valid === true, "No conflict escalation (all-veg household)");
assert(dadiDinnerDay0?.parallel_dishes_needed === 1, "Only 1 dish needed (no escalation)");

// All 7 days × 3 slots = 21 entries
assert(map1.size === 21, `Map has exactly 21 entries (got ${map1.size})`);

console.log("\n── FULL OUTPUT (day0_dinner) ────────────────────────────────────");
console.log(JSON.stringify(dadiDinnerDay0, null, 2));

console.log("\n── PROMPT INJECTION SAMPLE (first 3000 chars) ──────────────────");
const injection1 = buildModifierInjectionSection(map1);
console.log(injection1.slice(0, 3000));

// =============================================================================
// TEST 2 — Non-veg Household + Strictly Vegetarian Grandmother (Conflict Escalation)
// =============================================================================

console.log("\n");
console.log("═══════════════════════════════════════════════════════════════");
console.log("TEST 2 — Non-veg Household + Strictly Vegetarian Grandmother (Escalation)");
console.log("═══════════════════════════════════════════════════════════════");

const packet2 = buildMinimalPacket([
  {
    id: "member-5",
    name: "Anoop",
    age: 40,
    gender: "male",
    effectiveWeightKg: 94,
    effectiveHealthConditions: ["high_cholesterol", "obesity"],
    dietaryType: "non_vegetarian",
    allergies: ["shellfish"],
    effectiveGoal: "weight_loss",
    goalPace: "moderate_0.5kg",
    dailyCalorieTarget: 2000,
  },
  {
    id: "member-6",
    name: "Divya",
    age: 36,
    gender: "female",
    effectiveWeightKg: 65,
    effectiveHealthConditions: ["pcos"],
    dietaryType: "non_vegetarian",
    allergies: [],
    effectiveGoal: "manage_condition",
    dailyCalorieTarget: 1700,
  },
  {
    id: "member-7",
    name: "Ammachi",
    age: 70,
    gender: "female",
    effectiveWeightKg: 58,
    effectiveHealthConditions: ["hypertension"],
    dietaryType: "strictly_vegetarian",
    religiousCulturalRules: { type: "no_beef", details: [] },
    allergies: [],
    effectiveGoal: "senior_nutrition",
    dailyCalorieTarget: 1500,
    isSenior: true,
  },
]);

const map2 = buildMemberModifierMap(packet2, slotWeights);

console.log("\n── ASSERTIONS ──────────────────────────────────────────────────");

const dinnerDay0Test2 = map2.get("day0_dinner");

// Must escalate: non-veg members + strictly vegetarian Ammachi
assert(dinnerDay0Test2?.base_dish_is_valid === false, "Conflict escalation triggered (non-veg vs strictly-veg)");
assert((dinnerDay0Test2?.parallel_dishes_needed ?? 1) === 2, "parallel_dishes_needed === 2");
assert(dinnerDay0Test2?.escalation_reason !== null, "escalation_reason is populated");
assert(dinnerDay0Test2?.escalation_solution !== null, "escalation_solution is populated");

// Ammachi must have modifications mentioning vegetarian
const ammachi = dinnerDay0Test2?.member_plates.find((p) => p.member_name === "Ammachi");
assert(ammachi !== undefined, "Ammachi plate exists");
const ammachiBloacked = ammachi?.modifications.some(
  (m) => m.toLowerCase().includes("hypertension") || m.toLowerCase().includes("salt") || m.toLowerCase().includes("sodium")
);
assert(ammachiBloacked === true, "Ammachi has hypertension modifications");

// Anoop must have high_cholesterol modifications
const anoop = dinnerDay0Test2?.member_plates.find((p) => p.member_name === "Anoop");
assert(anoop !== undefined, "Anoop plate exists");
const anoopHasCholesterol = anoop?.modifications.some(
  (m) => m.toLowerCase().includes("cholesterol") || m.toLowerCase().includes("ghee")
);
assert(anoopHasCholesterol === true, "Anoop has high_cholesterol modification");

// Divya must have PCOS additives
const divya = dinnerDay0Test2?.member_plates.find((p) => p.member_name === "Divya");
assert(divya !== undefined, "Divya plate exists");
assert((divya?.additives.length ?? 0) > 0, "Divya has PCOS additives (flaxseed)");

// Anoop has shellfish allergy — must appear in withheld or modifications
const anoopShellfishBlocked =
  anoop?.withheld.some((w) => w.toLowerCase().includes("shellfish")) ||
  anoop?.modifications.some((m) => m.toLowerCase().includes("shellfish"));
assert(anoopShellfishBlocked === true, "Anoop shellfish allergy reflected in plate");

console.log("\n── FULL OUTPUT (day0_dinner, Test 2) ───────────────────────────");
console.log(JSON.stringify(dinnerDay0Test2, null, 2));

console.log("\n── ESCALATION DETAIL ───────────────────────────────────────────");
console.log("escalation_reason:", dinnerDay0Test2?.escalation_reason);
console.log("escalation_solution:", dinnerDay0Test2?.escalation_solution);

// =============================================================================
// SUMMARY
// =============================================================================

console.log("\n");
console.log("═══════════════════════════════════════════════════════════════");
console.log("ONE BASE MANY PLATES — TEST SUMMARY");
console.log("═══════════════════════════════════════════════════════════════");
console.log(`PASS: ${passCount}`);
console.log(`FAIL: ${failCount}`);
console.log(`TOTAL: ${passCount + failCount}`);
console.log(`RESULT: ${failCount === 0 ? "✅ ALL PASS — PRODUCTION READY" : `❌ ${failCount} FAILURE(S) — NEEDS WORK`}`);
console.log("═══════════════════════════════════════════════════════════════");
