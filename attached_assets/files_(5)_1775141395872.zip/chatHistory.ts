/**
 * FILE: server/lib/chatHistory.ts
 * PURPOSE: Save and retrieve persisted chat messages for a family session.
 *
 * INTEGRATION NOTES:
 *  - Import `db` and `chatMessages` from your actual schema/db paths.
 *  - The `chatMessages` table must be added to your schema first.
 *    See server/db/schema-chat-messages.ts for the exact block to copy.
 *  - Sessions are identified by a UUID (sessionId) generated on the client.
 *    Each device/browser tab maintains its own session.
 *  - Messages are capped at the last 100 per session to keep history loads fast.
 */

import { db }           from "../db";           // ← ADJUST PATH
import { chatMessages } from "../db/schema";     // ← ADJUST PATH — add chatMessages to your schema import
import { eq, and, desc } from "drizzle-orm";

// ─────────────────────────────────────────────
// TYPES
// ─────────────────────────────────────────────

export interface HistoryMessage {
  id:        number;
  role:      "user" | "assistant";
  text:      string;
  createdAt: string; // ISO string — safe to pass to JSON responses
}

// ─────────────────────────────────────────────
// SAVE A SINGLE MESSAGE
// Called twice per exchange: once for the user message (before streaming),
// once for the assistant message (after the stream completes).
// ─────────────────────────────────────────────

export async function saveChatMessage(params: {
  familyId:  number;
  sessionId: string;
  role:      "user" | "assistant";
  text:      string;
}): Promise<void> {
  const { familyId, sessionId, role, text } = params;

  // Validate: never persist empty messages or raw action JSON
  if (!text || !text.trim()) return;
  if (text.includes("---ACTION---")) {
    console.warn("[ChatHistory] Attempted to save message containing action delimiter. Stripped.");
  }

  // Strip the action block before saving — the DB stores only conversational text
  const cleanText = text.includes("---ACTION---")
    ? text.slice(0, text.indexOf("---ACTION---")).trim()
    : text.trim();

  if (!cleanText) return;

  // Validate sessionId is a non-empty string (client-generated UUID)
  if (!sessionId || typeof sessionId !== "string" || sessionId.trim().length === 0) {
    console.error("[ChatHistory] Invalid sessionId — message not saved.");
    return;
  }

  try {
    await db.insert(chatMessages).values({
      familyId,
      sessionId: sessionId.trim(),
      role,
      text: cleanText,
    });
  } catch (err) {
    // Log but never throw — a history save failure must NEVER interrupt the chat stream
    console.error("[ChatHistory] Failed to save message:", err);
  }
}

// ─────────────────────────────────────────────
// LOAD HISTORY FOR A SESSION
// Returns messages in ascending chronological order (oldest first)
// so the frontend can render them top-to-bottom naturally.
// ─────────────────────────────────────────────

export async function loadChatHistory(params: {
  familyId:  number;
  sessionId: string;
  limit?:    number; // default: 100
}): Promise<HistoryMessage[]> {
  const { familyId, sessionId, limit = 100 } = params;

  if (!sessionId || typeof sessionId !== "string" || sessionId.trim().length === 0) {
    return [];
  }

  if (!Number.isInteger(familyId) || familyId <= 0) {
    return [];
  }

  try {
    // Fetch the most recent `limit` messages, then reverse to get ascending order
    const rows = await db
      .select({
        id:        chatMessages.id,
        role:      chatMessages.role,
        text:      chatMessages.text,
        createdAt: chatMessages.createdAt,
      })
      .from(chatMessages)
      .where(
        and(
          eq(chatMessages.familyId, familyId),
          eq(chatMessages.sessionId, sessionId.trim())
        )
      )
      .orderBy(desc(chatMessages.createdAt))
      .limit(limit);

    // Reverse to chronological order (oldest first for display)
    return rows
      .reverse()
      .map((row: any) => ({
        id:        row.id,
        role:      row.role as "user" | "assistant",
        text:      row.text,
        createdAt: new Date(row.createdAt).toISOString(),
      }));
  } catch (err) {
    console.error("[ChatHistory] Failed to load history:", err);
    return []; // Return empty array — the chat still works, just without history
  }
}

// ─────────────────────────────────────────────
// LIST SESSIONS FOR A FAMILY
// Returns a deduplicated list of all session IDs for this family,
// each with the timestamp of its first message.
// Used if you want to show a "Previous conversations" list in the UI.
// ─────────────────────────────────────────────

export async function listSessionsForFamily(familyId: number): Promise<
  { sessionId: string; startedAt: string; messageCount: number }[]
> {
  if (!Number.isInteger(familyId) || familyId <= 0) return [];

  try {
    // Drizzle doesn't have a direct GROUP BY sugar — use raw SQL for this query
    const rows = await db.execute(
      // This is standard SQL supported by all Postgres versions
      `SELECT
         session_id AS "sessionId",
         MIN(created_at) AS "startedAt",
         COUNT(*)::int AS "messageCount"
       FROM chat_messages
       WHERE family_id = ${familyId}
       GROUP BY session_id
       ORDER BY MIN(created_at) DESC
       LIMIT 20`
    );

    return (rows as any[]).map((row: any) => ({
      sessionId:    row.sessionId,
      startedAt:    new Date(row.startedAt).toISOString(),
      messageCount: row.messageCount,
    }));
  } catch (err) {
    console.error("[ChatHistory] Failed to list sessions:", err);
    return [];
  }
}
