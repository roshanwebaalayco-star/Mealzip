/**
 * FILE: server/db/schema-chat-messages.ts
 * ─────────────────────────────────────────────────────────────────
 * THIS IS NOT A STANDALONE FILE.
 *
 * Copy the block below into your existing Drizzle schema file
 * (wherever your other tables like familyMembers, mealPlans etc. live).
 *
 * Then run your migration command — usually:
 *   npm run db:push   OR   npx drizzle-kit push
 *
 * Do NOT change any existing table definitions.
 * Only ADD this new table.
 * ─────────────────────────────────────────────────────────────────
 */

// ─── ADD THIS BLOCK TO YOUR SCHEMA FILE ───────────────────────────

import { pgTable, serial, integer, text, timestamp } from "drizzle-orm/pg-core";

export const chatMessages = pgTable("chat_messages", {
  id:        serial("id").primaryKey(),

  // Links chat history to the authenticated family
  familyId:  integer("family_id").notNull(),

  // UUID generated on the client (stored in sessionStorage).
  // Groups messages belonging to one continuous chat session.
  // A new session = new UUID = fresh chat thread in the UI.
  sessionId: text("session_id").notNull(),

  // "user" or "assistant" — matches ChatMessage.role on the frontend
  role:      text("role").notNull(),

  // The full rendered text of the message (action JSON is NEVER stored here —
  // it is stripped by parseActionFromResponse before this is saved)
  text:      text("text").notNull(),

  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ─── END OF BLOCK ─────────────────────────────────────────────────
