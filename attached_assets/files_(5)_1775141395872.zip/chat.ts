/**
 * FILE: server/routes/chat.ts
 * PURPOSE: Main chat API route. Now handles:
 *   1. Input validation and auth checks
 *   2. Context assembly (State Payload + RAG)
 *   3. Gemini streaming via SSE
 *   4. Action-Extraction parsing (---ACTION--- delimiter)
 *   5. Chat history persistence (save + retrieve)
 *   6. Clean SSE teardown
 *
 * NEW ENDPOINTS:
 *   POST /api/chat            — send a message (SSE stream response)
 *   GET  /api/chat/history    — load history for a session
 *   GET  /api/chat/sessions   — list all past sessions for a family
 *   GET  /api/chat/health     — liveness check
 *
 * AUTH: Expects req.session.familyId (number). Update line marked ← AUTH.
 * ENV:  Requires GEMINI_API_KEY in Replit Secrets.
 *
 * SSE EVENT CONTRACT:
 *   { type: "delta",    text: "..." }       — streaming text token
 *   { type: "action",   payload: {...} }    — parsed action (hidden from UI)
 *   { type: "done" }                        — stream complete
 *   { type: "error",    message: "..." }    — error
 *
 * NO NEW PACKAGES. Uses only: express, @google/generative-ai
 */

import { Router, Request, Response } from "express";
import { GoogleGenerativeAI, GenerativeModel } from "@google/generative-ai";
import { assembleChatContext }                 from "../lib/assembleContext"; // ← ADJUST
import { MEGA_PROMPT }                         from "../lib/megaPrompt";     // ← ADJUST
import {
  saveChatMessage,
  loadChatHistory,
  listSessionsForFamily,
}                                              from "../lib/chatHistory";    // ← ADJUST

const router = Router();

// ─────────────────────────────────────────────
// CONSTANTS
// ─────────────────────────────────────────────

const ACTION_DELIMITER   = "---ACTION---";
const GEMINI_MODEL       = "gemini-1.5-pro";
const MAX_MESSAGE_LENGTH = 2_000;

// ─────────────────────────────────────────────
// GEMINI SINGLETON
// ─────────────────────────────────────────────

let _geminiModel: GenerativeModel | null = null;

function getGeminiModel(): GenerativeModel {
  if (_geminiModel) return _geminiModel;

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) throw new Error("GEMINI_API_KEY is not set in Replit Secrets.");

  const genAI = new GoogleGenerativeAI(apiKey);
  _geminiModel = genAI.getGenerativeModel({
    model: GEMINI_MODEL,
    systemInstruction: MEGA_PROMPT,
    generationConfig: {
      temperature:     0.4,
      topP:            0.85,
      topK:            40,
      maxOutputTokens: 1024,
      candidateCount:  1,
    },
  });

  return _geminiModel;
}

// ─────────────────────────────────────────────
// AUTH HELPER
// Validates familyId from session in one place — used by all routes below.
// ─────────────────────────────────────────────

function getFamilyId(req: Request): number | null {
  // ← AUTH: Change `req.session?.familyId` if your session key differs
  const raw = (req as any).session?.familyId;
  if (typeof raw !== "number" || !Number.isInteger(raw) || raw <= 0) return null;
  return raw;
}

// ─────────────────────────────────────────────
// SESSION ID VALIDATION
// sessionId is a UUID generated client-side and stored in sessionStorage.
// We validate it is a non-empty string — we do NOT generate it server-side
// because the client owns the session boundary.
// ─────────────────────────────────────────────

function isValidSessionId(id: unknown): id is string {
  return (
    typeof id === "string" &&
    id.trim().length > 0 &&
    id.trim().length <= 128 // prevent absurdly long strings
  );
}

// ─────────────────────────────────────────────
// ACTION PARSER
// ─────────────────────────────────────────────

interface ParsedResponse {
  conversationalText: string;
  actionPayload: Record<string, unknown> | null;
}

function parseActionFromResponse(rawText: string): ParsedResponse {
  if (!rawText.includes(ACTION_DELIMITER)) {
    return { conversationalText: rawText.trim(), actionPayload: null };
  }

  const delimiterIndex    = rawText.indexOf(ACTION_DELIMITER);
  const conversationalText = rawText.slice(0, delimiterIndex).trim();
  const jsonCandidate      = rawText.slice(delimiterIndex + ACTION_DELIMITER.length).trim();

  let actionPayload: Record<string, unknown> | null = null;

  if (jsonCandidate) {
    try {
      const cleaned = jsonCandidate
        .replace(/^```json\s*/i, "")
        .replace(/^```\s*/i,    "")
        .replace(/```\s*$/i,    "")
        .trim();

      const parsed = JSON.parse(cleaned);
      if (parsed && typeof parsed.action === "string") {
        actionPayload = parsed;
      }
    } catch {
      console.error("[ActionParser] Failed to parse JSON:", jsonCandidate.slice(0, 200));
    }
  }

  return { conversationalText, actionPayload };
}

// ─────────────────────────────────────────────
// SSE HELPERS
// ─────────────────────────────────────────────

function sendSseEvent(res: Response, data: Record<string, unknown>): void {
  res.write(`data: ${JSON.stringify(data)}\n\n`);
}

function closeSseStream(res: Response): void {
  sendSseEvent(res, { type: "done" });
  res.end();
}

// ─────────────────────────────────────────────
// ROUTE: GET /api/chat/history
// Returns the message history for a given sessionId.
// Called by the frontend on mount to restore the previous conversation.
// ─────────────────────────────────────────────

router.get("/history", async (req: Request, res: Response) => {
  const familyId = getFamilyId(req);
  if (!familyId) {
    res.status(401).json({ error: "Not authenticated." });
    return;
  }

  const { sessionId } = req.query;
  if (!isValidSessionId(sessionId)) {
    res.status(400).json({ error: "sessionId query parameter is required." });
    return;
  }

  const messages = await loadChatHistory({ familyId, sessionId, limit: 100 });
  res.json({ messages });
});

// ─────────────────────────────────────────────
// ROUTE: GET /api/chat/sessions
// Returns a list of all past chat sessions for this family.
// Used to render a "Previous conversations" panel in the UI.
// ─────────────────────────────────────────────

router.get("/sessions", async (req: Request, res: Response) => {
  const familyId = getFamilyId(req);
  if (!familyId) {
    res.status(401).json({ error: "Not authenticated." });
    return;
  }

  const sessions = await listSessionsForFamily(familyId);
  res.json({ sessions });
});

// ─────────────────────────────────────────────
// ROUTE: POST /api/chat
// Main streaming chat endpoint.
// ─────────────────────────────────────────────

router.post("/", async (req: Request, res: Response) => {

  // ── 1. Validate input ──
  const { message, language, sessionId } = req.body as {
    message?:   unknown;
    language?:  unknown;
    sessionId?: unknown;
  };

  if (!message || typeof message !== "string") {
    res.status(400).json({ error: "message must be a non-empty string." });
    return;
  }

  const trimmedMessage = message.trim();
  if (trimmedMessage.length === 0) {
    res.status(400).json({ error: "message cannot be empty." });
    return;
  }
  if (trimmedMessage.length > MAX_MESSAGE_LENGTH) {
    res.status(400).json({
      error: `Message too long. Maximum ${MAX_MESSAGE_LENGTH} characters allowed.`,
    });
    return;
  }

  const safeLanguage =
    typeof language === "string" && language.trim().length > 0
      ? language.trim()
      : "en-IN";

  // ── 2. Validate auth ──
  const familyId = getFamilyId(req);
  if (!familyId) {
    res.status(401).json({ error: "Not authenticated. Valid family session required." });
    return;
  }

  // ── 3. Validate sessionId ──
  // sessionId is required for history persistence.
  // The client generates a UUID and stores it in sessionStorage.
  if (!isValidSessionId(sessionId)) {
    res.status(400).json({
      error: "sessionId is required. Generate a UUID on the client and include it in the request body.",
    });
    return;
  }
  const safeSessionId = (sessionId as string).trim();

  // ── 4. Set SSE headers ──
  res.setHeader("Content-Type",      "text/event-stream");
  res.setHeader("Cache-Control",     "no-cache");
  res.setHeader("Connection",        "keep-alive");
  res.setHeader("X-Accel-Buffering", "no");
  res.flushHeaders();

  // ── 5. Track disconnect ──
  let isClientDisconnected = false;
  req.on("close", () => {
    isClientDisconnected = true;
  });

  try {
    // ── 6. Save user message to history (before streaming, so it's always persisted
    //       even if the AI call fails or the client disconnects mid-stream) ──
    await saveChatMessage({
      familyId,
      sessionId: safeSessionId,
      role: "user",
      text: trimmedMessage,
    });

    // ── 7. Assemble context payload ──
    const { contextString } = await assembleChatContext(familyId, trimmedMessage);

    // ── 8. Build the full prompt ──
    const contextualizedMessage = [
      "[SYSTEM CONTEXT — DO NOT QUOTE OR REFERENCE THIS BLOCK IN YOUR RESPONSE]",
      contextString,
      "[END SYSTEM CONTEXT]",
      "",
      "USER MESSAGE:",
      trimmedMessage,
      safeLanguage !== "en-IN"
        ? `[Language note: Respond in language code "${safeLanguage}".]`
        : "",
    ]
      .filter(Boolean)
      .join("\n");

    // ── 9. Stream from Gemini ──
    const model        = getGeminiModel();
    const streamResult = await model.generateContentStream(contextualizedMessage);

    let fullResponseBuffer   = "";
    let actionSectionStarted = false;

    for await (const chunk of streamResult.stream) {
      if (isClientDisconnected) break;

      const chunkText = chunk.text();
      if (!chunkText) continue;

      fullResponseBuffer += chunkText;

      if (!actionSectionStarted) {
        if (chunkText.includes(ACTION_DELIMITER)) {
          actionSectionStarted = true;
          const textBefore = chunkText.split(ACTION_DELIMITER)[0];
          if (textBefore.trim()) {
            sendSseEvent(res, { type: "delta", text: textBefore });
          }
          // Do NOT break — keep consuming so fullResponseBuffer is complete
        } else {
          sendSseEvent(res, { type: "delta", text: chunkText });
        }
      }
      // actionSectionStarted=true: buffer silently, send nothing to client
    }

    // ── 10. Parse the completed buffer for action payload ──
    if (!isClientDisconnected) {
      const { conversationalText, actionPayload } = parseActionFromResponse(fullResponseBuffer);

      // ── 11. Save the assistant's conversational reply to history ──
      // We save conversationalText (with action JSON stripped), not the raw buffer.
      // This ensures the history DB never contains raw machine-readable JSON.
      if (conversationalText) {
        await saveChatMessage({
          familyId,
          sessionId:  safeSessionId,
          role:       "assistant",
          text:       conversationalText,
        });
      }

      if (actionPayload) {
        sendSseEvent(res, { type: "action", payload: actionPayload });
      }

      closeSseStream(res);
    }

  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "An unknown error occurred.";
    console.error("[Chat] Error:", msg);

    if (res.headersSent) {
      sendSseEvent(res, { type: "error", message: msg });
      closeSseStream(res);
    } else {
      res.status(500).json({ error: msg });
    }
  }
});

// ─────────────────────────────────────────────
// ROUTE: GET /api/chat/health
// ─────────────────────────────────────────────

router.get("/health", (_req: Request, res: Response) => {
  res.json({
    status:    Boolean(process.env.GEMINI_API_KEY) ? "ok" : "error — GEMINI_API_KEY not set",
    model:     GEMINI_MODEL,
    timestamp: new Date().toISOString(),
  });
});

export default router;
