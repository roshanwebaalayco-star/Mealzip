/**
 * FILE: client/hooks/useChat.ts
 * PURPOSE: Full chat lifecycle including history persistence.
 *
 * WHAT'S NEW vs the previous version:
 *   1. Session management — generates/restores a UUID sessionId from sessionStorage.
 *      Each browser session gets its own UUID. Refreshing the page restores the
 *      same session. Opening a new tab starts a new session.
 *   2. History loading — on mount, fetches previous messages for this sessionId
 *      from GET /api/chat/history and pre-populates the messages array.
 *   3. sessionId is sent with every POST /api/chat so the server can persist both
 *      the user message and the assistant reply.
 *
 * NO NEW PACKAGES REQUIRED.
 */

import { useState, useRef, useCallback, useEffect } from "react";
import { useSpeechSynthesis } from "./useVoice";

// ─────────────────────────────────────────────
// SESSION ID MANAGEMENT
// UUID generated once per browser session and stored in sessionStorage.
// sessionStorage is cleared when the tab is closed — opening a new tab
// starts a new conversation thread. Refreshing the page restores the session.
//
// MOBILE NOTE: In Capacitor/React Native Web, sessionStorage behaves
// identically to a web browser.
// ─────────────────────────────────────────────

const SESSION_STORAGE_KEY = "ps_chat_session_id";

function getOrCreateSessionId(): string {
  // Guard for SSR / non-browser environments
  if (typeof window === "undefined" || !window.sessionStorage) {
    return `session_${Date.now()}`;
  }

  const existing = sessionStorage.getItem(SESSION_STORAGE_KEY);
  if (existing && existing.trim().length > 0) return existing;

  // Generate a simple UUID v4
  const uuid = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === "x" ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });

  sessionStorage.setItem(SESSION_STORAGE_KEY, uuid);
  return uuid;
}

// ─────────────────────────────────────────────
// UTILITY
// ─────────────────────────────────────────────

function generateId(): string {
  return `msg_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
}

// ─────────────────────────────────────────────
// TYPES
// ─────────────────────────────────────────────

export type MessageRole = "user" | "assistant";

export interface ChatMessage {
  id:          string;
  role:        MessageRole;
  text:        string;
  timestamp:   Date;
  isStreaming?: boolean;
  fromHistory?: boolean; // True for messages loaded from DB (not this session's live messages)
}

export type ActionType =
  | "leftover_suggestion"
  | "cheat_meal_detected"
  | "medication_conflict_warning"
  | "meal_plan_query";

export interface ActionPayload {
  action: ActionType;
  [key: string]: unknown;
}

interface ActionCardMeta {
  buttonLabel: string;
  description: string;
  variant:     "primary" | "warning" | "info";
}

// ─────────────────────────────────────────────
// ACTION → UI CARD MAPPING
// ─────────────────────────────────────────────

export function getActionCardMeta(payload: ActionPayload): ActionCardMeta {
  switch (payload.action) {
    case "leftover_suggestion":
      return {
        buttonLabel: `Update Tomorrow's Plan with ${payload.dish ?? "suggested dish"}`,
        description: `Use leftover ${payload.ingredient ?? "ingredient"} for ${payload.mealSlot ?? "a meal"} tomorrow.`,
        variant: "primary",
      };
    case "cheat_meal_detected":
      return {
        buttonLabel: "Log Adjustment to This Week",
        description: `Tomorrow's ${payload.adjustedMeal ?? "meal"} will be rebalanced for ${payload.reason ?? "macros"}.`,
        variant: "info",
      };
    case "medication_conflict_warning":
      return {
        buttonLabel: "View Safe Meal Window",
        description: `⚠️ ${payload.member ?? "A family member"}'s ${payload.drug ?? "medication"} conflicts with ${payload.conflict ?? "this food"}.`,
        variant: "warning",
      };
    case "meal_plan_query":
      return {
        buttonLabel: "Apply This Change to Plan",
        description: `Change ${payload.slot ?? "meal"} on ${payload.day ?? "the scheduled day"} to ${payload.newMeal ?? "the new meal"}.`,
        variant: "primary",
      };
    default:
      return {
        buttonLabel: "Take Action",
        description: "The assistant has a suggestion.",
        variant: "info",
      };
  }
}

// ─────────────────────────────────────────────
// HOOK: useChat
// ─────────────────────────────────────────────

interface UseChatOptions {
  language?:    string;
  enableVoice?: boolean;
}

interface UseChatReturn {
  messages:       ChatMessage[];
  pendingAction:  ActionPayload | null;
  isLoading:      boolean;
  isLoadingHistory: boolean;
  error:          string | null;
  sessionId:      string;
  sendMessage:    (text: string) => Promise<void>;
  dismissAction:  () => void;
  clearError:     () => void;
  startNewSession: () => void; // Clears sessionStorage and resets the chat
  isSpeaking:     boolean;
  cancelSpeech:   () => void;
}

export function useChat(options: UseChatOptions = {}): UseChatReturn {
  const { language = "en-IN", enableVoice = true } = options;

  const [messages,          setMessages]          = useState<ChatMessage[]>([]);
  const [pendingAction,     setPendingAction]     = useState<ActionPayload | null>(null);
  const [isLoading,         setIsLoading]         = useState(false);
  const [isLoadingHistory,  setIsLoadingHistory]  = useState(true); // true on mount
  const [error,             setError]             = useState<string | null>(null);
  const [sessionId,         setSessionId]         = useState<string>(() => getOrCreateSessionId());

  const abortControllerRef = useRef<AbortController | null>(null);

  const { speakDelta, flushBuffer, cancelSpeech, isSpeaking, setLanguage } =
    useSpeechSynthesis();

  // Sync language to TTS hook
  useEffect(() => {
    setLanguage(language);
  }, [language, setLanguage]);

  // ─────────────────────────────────────────────
  // LOAD HISTORY ON MOUNT (and when sessionId changes)
  // Fetches previous messages from the server and pre-populates the chat.
  // ─────────────────────────────────────────────

  useEffect(() => {
    let cancelled = false;

    async function fetchHistory() {
      setIsLoadingHistory(true);
      setMessages([]); // Clear current messages before loading history

      try {
        const res = await fetch(
          `/api/chat/history?sessionId=${encodeURIComponent(sessionId)}`
        );

        if (!res.ok) {
          // 401 = not authenticated yet — silent fail, chat still works
          if (res.status !== 401) {
            console.warn("[Chat] History fetch failed:", res.status);
          }
          return;
        }

        const data = await res.json();
        const historyMessages: ChatMessage[] = (data.messages ?? []).map(
          (m: { id: number; role: string; text: string; createdAt: string }) => ({
            id:          `history_${m.id}`,
            role:        m.role as MessageRole,
            text:        m.text,
            timestamp:   new Date(m.createdAt),
            isStreaming: false,
            fromHistory: true,
          })
        );

        if (!cancelled) {
          setMessages(historyMessages);
        }
      } catch (err) {
        // Network error or server down — silent fail, chat still works
        console.warn("[Chat] Could not load chat history:", err);
      } finally {
        if (!cancelled) setIsLoadingHistory(false);
      }
    }

    fetchHistory();
    return () => { cancelled = true; };
  }, [sessionId]);

  // ─────────────────────────────────────────────
  // START NEW SESSION
  // Clears sessionStorage and starts a fresh conversation thread.
  // ─────────────────────────────────────────────

  const startNewSession = useCallback(() => {
    if (typeof window !== "undefined" && window.sessionStorage) {
      sessionStorage.removeItem(SESSION_STORAGE_KEY);
    }
    const newId = getOrCreateSessionId();
    setSessionId(newId);
    setPendingAction(null);
    setError(null);
    cancelSpeech();
  }, [cancelSpeech]);

  const dismissAction = useCallback(() => setPendingAction(null), []);
  const clearError    = useCallback(() => setError(null),         []);

  // ─────────────────────────────────────────────
  // SEND MESSAGE
  // ─────────────────────────────────────────────

  const sendMessage = useCallback(
    async (text: string) => {
      if (!text.trim() || isLoading) return;

      if (isSpeaking) cancelSpeech();

      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }

      const controller = new AbortController();
      abortControllerRef.current = controller;

      const userMessage: ChatMessage = {
        id:        generateId(),
        role:      "user",
        text:      text.trim(),
        timestamp: new Date(),
      };

      const assistantMessageId = generateId();
      const assistantMessage: ChatMessage = {
        id:          assistantMessageId,
        role:        "assistant",
        text:        "",
        timestamp:   new Date(),
        isStreaming: true,
      };

      setMessages((prev) => [...prev, userMessage, assistantMessage]);
      setIsLoading(true);
      setError(null);
      setPendingAction(null);

      try {
        const response = await fetch("/api/chat", {
          method:  "POST",
          headers: { "Content-Type": "application/json" },
          body:    JSON.stringify({
            message:   text.trim(),
            language,
            sessionId, // ← sent so the server can persist both messages
          }),
          signal: controller.signal,
        });

        if (!response.ok) {
          const errData = await response.json().catch(() => ({ error: "Request failed" }));
          throw new Error(errData.error ?? `HTTP ${response.status}`);
        }

        if (!response.body) throw new Error("No response body.");

        const reader      = response.body.getReader();
        const decoder     = new TextDecoder("utf-8");
        let   streamBuffer = "";

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          streamBuffer += decoder.decode(value, { stream: true });
          const lines   = streamBuffer.split("\n\n");
          streamBuffer  = lines.pop() ?? "";

          for (const line of lines) {
            if (!line.trim()) continue;
            const dataLine = line.startsWith("data: ") ? line.slice(6) : line;

            let event: Record<string, unknown>;
            try {
              event = JSON.parse(dataLine);
            } catch {
              continue;
            }

            switch (event.type) {
              case "delta": {
                const token = event.text as string;
                setMessages((prev) =>
                  prev.map((msg) =>
                    msg.id === assistantMessageId
                      ? { ...msg, text: msg.text + token }
                      : msg
                  )
                );
                if (enableVoice) speakDelta(token);
                break;
              }
              case "action": {
                const payload = event.payload as ActionPayload;
                if (payload?.action) setPendingAction(payload);
                break;
              }
              case "done": {
                setMessages((prev) =>
                  prev.map((msg) =>
                    msg.id === assistantMessageId
                      ? { ...msg, isStreaming: false }
                      : msg
                  )
                );
                if (enableVoice) flushBuffer();
                break;
              }
              case "error": {
                throw new Error(event.message as string);
              }
            }
          }
        }

      } catch (err: unknown) {
        // Clean up streaming cursor on AbortError too
        setMessages((prev) =>
          prev.map((msg) =>
            msg.id === assistantMessageId
              ? { ...msg, isStreaming: false }
              : msg
          )
        );

        if (err instanceof Error && err.name === "AbortError") return;

        const errorMsg = err instanceof Error ? err.message : "An unknown error occurred.";
        console.error("[Chat] Stream error:", errorMsg);
        setError(errorMsg);

        setMessages((prev) =>
          prev.map((msg) =>
            msg.id === assistantMessageId
              ? { ...msg, text: msg.text || "An error occurred. Please try again." }
              : msg
          )
        );
      } finally {
        setIsLoading(false);
        abortControllerRef.current = null;
      }
    },
    [isLoading, isSpeaking, language, sessionId, enableVoice, cancelSpeech, speakDelta, flushBuffer]
  );

  return {
    messages,
    pendingAction,
    isLoading,
    isLoadingHistory,
    error,
    sessionId,
    sendMessage,
    dismissAction,
    clearError,
    startNewSession,
    isSpeaking,
    cancelSpeech,
  };
}
