/**
 * FILE: server/routes/chat.ts
 * PURPOSE: The main chat API route. Handles:
 *   1. Input validation and auth checks
 *   2. Context assembly (State Payload + RAG)
 *   3. Gemini streaming via SSE (Server-Sent Events)
 *   4. Action-Extraction parsing (---ACTION--- delimiter)
 *   5. Clean SSE teardown and disconnect handling
 *
 * INTEGRATION: In your server/index.ts or server/app.ts, add:
 *   import chatRouter from "./routes/chat";
 *   app.use("/api/chat", chatRouter);
 *
 * AUTH: Expects req.session.familyId (number) from your existing auth middleware.
 *   Update the one line marked ← AUTH if your session key differs.
 *
 * ENV: Requires GEMINI_API_KEY in Replit Secrets.
 *
 * SSE EVENT CONTRACT (what the frontend receives):
 *   { type: "delta",  text: "..." }         — streaming text token
 *   { type: "action", payload: {...} }      — parsed action (hidden from chat UI)
 *   { type: "done" }                        — stream complete
 *   { type: "error",  message: "..." }      — error during generation
 *
 * NO NEW PACKAGES. Uses only: express, @google/generative-ai
 */

import { Router, Request, Response } from "express";
import { GoogleGenerativeAI, GenerativeModel } from "@google/generative-ai";
import { assembleChatContext } from "../lib/assembleContext"; // ← ADJUST PATH IF NEEDED
import { MEGA_PROMPT }         from "../lib/megaPrompt";     // ← ADJUST PATH IF NEEDED

const router = Router();

// ─────────────────────────────────────────────
// CONSTANTS
// ─────────────────────────────────────────────

const ACTION_DELIMITER = "---ACTION---";
const GEMINI_MODEL     = "gemini-1.5-pro"; // Switch to "gemini-1.5-flash" for lower latency

// FIX #1: Hard cap on message length to prevent DoS and runaway API costs.
// A 100,000-character message would still pass the previous `trim().length > 0`
// check and hit Gemini's 1M context window. 2000 chars is generous for any
// reasonable nutrition/health query.
const MAX_MESSAGE_LENGTH = 2_000;

// ─────────────────────────────────────────────
// FIX #2: GEMINI SDK SINGLETON
// Previously the GoogleGenerativeAI client and model were instantiated inside
// the request handler — a new object on every single request. This wastes
// memory and adds unnecessary construction overhead under load.
// Initialized lazily on first request so the env check is still useful.
// ─────────────────────────────────────────────

let _geminiModel: GenerativeModel | null = null;

function getGeminiModel(): GenerativeModel {
  if (_geminiModel) return _geminiModel;

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error(
      "GEMINI_API_KEY is not set. Add it to Replit Secrets and restart the server."
    );
  }

  const genAI = new GoogleGenerativeAI(apiKey);
  _geminiModel = genAI.getGenerativeModel({
    model: GEMINI_MODEL,
    systemInstruction: MEGA_PROMPT,
    generationConfig: {
      temperature:      0.4,   // Clinical precision over creativity
      topP:             0.85,
      topK:             40,
      maxOutputTokens:  1024,  // Enough for meal adjustments + action JSON
      candidateCount:   1,
    },
  });

  return _geminiModel;
}

// ─────────────────────────────────────────────
// ACTION PARSER
// Splits raw Gemini response on ---ACTION--- delimiter.
// ─────────────────────────────────────────────

interface ParsedResponse {
  conversationalText: string;
  actionPayload: Record<string, unknown> | null;
}

function parseActionFromResponse(rawText: string): ParsedResponse {
  if (!rawText.includes(ACTION_DELIMITER)) {
    return { conversationalText: rawText.trim(), actionPayload: null };
  }

  const delimiterIndex = rawText.indexOf(ACTION_DELIMITER);
  const conversationalText = rawText.slice(0, delimiterIndex).trim();
  const jsonCandidate      = rawText.slice(delimiterIndex + ACTION_DELIMITER.length).trim();

  let actionPayload: Record<string, unknown> | null = null;

  if (jsonCandidate) {
    try {
      // Strip accidental markdown code fences that Gemini sometimes adds
      const cleaned = jsonCandidate
        .replace(/^```json\s*/i, "")
        .replace(/^```\s*/i,    "")
        .replace(/```\s*$/i,    "")
        .trim();

      const parsed = JSON.parse(cleaned);

      // Must have a string "action" field to be a valid action payload
      if (parsed && typeof parsed.action === "string") {
        actionPayload = parsed;
      } else {
        console.warn("[ActionParser] JSON parsed but missing string 'action' key. Discarding.");
      }
    } catch (e) {
      // Log the offending text for debugging but don't crash
      console.error(
        "[ActionParser] Failed to parse action JSON:",
        jsonCandidate.slice(0, 200)
      );
    }
  }

  return { conversationalText, actionPayload };
}

// ─────────────────────────────────────────────
// SSE HELPERS
// ─────────────────────────────────────────────

function sendSseEvent(res: Response, data: Record<string, unknown>): void {
  res.write(`data: ${JSON.stringify(data)}\n\n`);
}

function closeSseStream(res: Response): void {
  sendSseEvent(res, { type: "done" });
  res.end();
}

// ─────────────────────────────────────────────
// ROUTE: POST /api/chat
// ─────────────────────────────────────────────

router.post("/", async (req: Request, res: Response) => {

  // ── 1. Parse and validate the request body ──
  const { message, language } = req.body as {
    message?: unknown;
    language?: unknown;
  };

  // Validate message type
  if (!message || typeof message !== "string") {
    res.status(400).json({ error: "message must be a non-empty string." });
    return;
  }

  const trimmedMessage = message.trim();
  if (trimmedMessage.length === 0) {
    res.status(400).json({ error: "message cannot be empty or whitespace only." });
    return;
  }

  // FIX #1: Enforce message length limit
  if (trimmedMessage.length > MAX_MESSAGE_LENGTH) {
    res.status(400).json({
      error: `Message too long. Maximum ${MAX_MESSAGE_LENGTH} characters allowed.`,
    });
    return;
  }

  // Validate language (optional, string only)
  const safeLanguage =
    typeof language === "string" && language.trim().length > 0
      ? language.trim()
      : "en-IN";

  // ── 2. Validate familyId from session ──
  // ← AUTH: Update this line if your session stores familyId under a different key
  const familyIdRaw = (req as any).session?.familyId;

  // FIX #3: Proper type validation — `as number` doesn't validate at runtime.
  // A session with familyId: "abc", null, NaN, or 0 would pass the old `!familyId`
  // check and then cause incorrect DB queries or return another family's data.
  if (
    typeof familyIdRaw !== "number" ||
    !Number.isInteger(familyIdRaw) ||
    familyIdRaw <= 0
  ) {
    res.status(401).json({ error: "Not authenticated. Valid family session required." });
    return;
  }
  const familyId: number = familyIdRaw;

  // ── 3. Set SSE headers before any res.write() call ──
  res.setHeader("Content-Type",    "text/event-stream");
  res.setHeader("Cache-Control",   "no-cache");
  res.setHeader("Connection",      "keep-alive");
  res.setHeader("X-Accel-Buffering", "no"); // Prevent Nginx/Replit proxy buffering
  res.flushHeaders(); // Immediately signal to the client that the stream has started

  // ── 4. Track client disconnect to avoid writing to a closed socket ──
  let isClientDisconnected = false;
  req.on("close", () => {
    isClientDisconnected = true;
    console.info("[Chat] Client disconnected — stream will be abandoned.");
  });

  try {
    // ── 5. Assemble the full context payload (parallel DB + RAG) ──
    const { contextString } = await assembleChatContext(familyId, trimmedMessage);

    // ── 6. Build the contextualized prompt ──
    // The context is injected as a clearly-labelled block before the user message.
    // The [SYSTEM CONTEXT] wrapper instructs the AI not to quote this block directly.
    const contextualizedMessage = [
      "[SYSTEM CONTEXT — DO NOT QUOTE OR REFERENCE THIS BLOCK IN YOUR RESPONSE]",
      contextString,
      "[END SYSTEM CONTEXT]",
      "",
      "USER MESSAGE:",
      trimmedMessage,
      safeLanguage !== "en-IN"
        ? `[Language note: The user is communicating in language code "${safeLanguage}". Respond in the same language register.]`
        : "",
    ]
      .filter(Boolean)
      .join("\n");

    // ── 7. Get the Gemini model singleton ──
    const model = getGeminiModel();

    // ── 8. Start streaming from Gemini ──
    const streamResult = await model.generateContentStream(contextualizedMessage);

    // ── 9. Stream tokens to client AND buffer the full response ──
    //
    // FIX #4: CRITICAL — The previous version used `break` when it detected
    // the ---ACTION--- delimiter in a chunk. This abandoned the async generator
    // mid-stream, meaning subsequent chunks containing the action JSON were
    // never read. fullResponseBuffer would be incomplete and parseActionFromResponse
    // would fail to extract the action JSON.
    //
    // Fix: Use a flag `actionSectionStarted`. Once the delimiter is seen, stop
    // sending delta events to the client (the user should not see JSON), but
    // CONTINUE consuming all remaining chunks into fullResponseBuffer so that
    // parseActionFromResponse receives the complete response string.

    let fullResponseBuffer = "";
    let actionSectionStarted = false;

    for await (const chunk of streamResult.stream) {
      if (isClientDisconnected) break;

      const chunkText = chunk.text();
      if (!chunkText) continue;

      fullResponseBuffer += chunkText;

      if (!actionSectionStarted) {
        if (chunkText.includes(ACTION_DELIMITER)) {
          // This chunk contains the delimiter — send only the text before it
          actionSectionStarted = true;
          const textBeforeDelimiter = chunkText.split(ACTION_DELIMITER)[0];
          if (textBeforeDelimiter.trim()) {
            sendSseEvent(res, { type: "delta", text: textBeforeDelimiter });
          }
          // DO NOT break — continue consuming to fully buffer the action JSON
        } else {
          // Normal conversational chunk — forward to client
          sendSseEvent(res, { type: "delta", text: chunkText });
        }
      }
      // When actionSectionStarted is true: buffer silently, send nothing to client
    }

    // ── 10. Parse the complete buffered response for the action block ──
    if (!isClientDisconnected) {
      const { actionPayload } = parseActionFromResponse(fullResponseBuffer);

      if (actionPayload) {
        // Send the action as a distinct SSE event type.
        // The frontend intercepts this and renders a UI card — never raw text.
        sendSseEvent(res, { type: "action", payload: actionPayload });
      }
    }

    // ── 11. Close the stream cleanly ──
    if (!isClientDisconnected) {
      closeSseStream(res);
    }

  } catch (err: unknown) {
    const errorMessage =
      err instanceof Error ? err.message : "An unknown error occurred.";

    console.error("[Chat] Stream error:", errorMessage);

    // If SSE headers were already flushed, send an error event (not HTTP 500)
    // because the response status cannot be changed after headers are sent.
    if (res.headersSent) {
      sendSseEvent(res, { type: "error", message: errorMessage });
      closeSseStream(res);
    } else {
      res.status(500).json({ error: errorMessage });
    }
  }
});

// ─────────────────────────────────────────────
// ROUTE: GET /api/chat/health
// Confirms the route is registered and the Gemini key is present.
// ─────────────────────────────────────────────

router.get("/health", (_req: Request, res: Response) => {
  const hasApiKey = Boolean(process.env.GEMINI_API_KEY);
  res.json({
    status:    hasApiKey ? "ok" : "error — GEMINI_API_KEY not set",
    model:     GEMINI_MODEL,
    timestamp: new Date().toISOString(),
  });
});

export default router;
