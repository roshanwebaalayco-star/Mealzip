/**
 * FILE: client/hooks/useVoice.ts
 * PURPOSE: Two self-contained React hooks for native browser voice I/O.
 *
 *   useSpeechRecognition  — Microphone input (STT)
 *   useSpeechSynthesis    — Text-to-speech output with sentence streaming
 *
 * ZERO EXTERNAL DEPENDENCIES.
 * Uses only window.SpeechRecognition and window.speechSynthesis.
 *
 * BROWSER SUPPORT:
 *  - SpeechRecognition: Chrome/Edge ✅  Firefox ❌  Safari (iOS 14.5+) ✅
 *  - SpeechSynthesis:   All modern browsers ✅
 *  If SpeechRecognition is unavailable, isSupported = false.
 *  Chat.tsx shows a text input fallback in that case — no crash.
 */

import { useState, useRef, useCallback, useEffect, useMemo } from "react";

// ─────────────────────────────────────────────
// LANGUAGE CODE MAP
// BCP-47 language codes for the Web Speech API
// ─────────────────────────────────────────────

export const LANGUAGE_CODES: Record<string, string> = {
  English:   "en-IN",
  Hindi:     "hi-IN",
  Tamil:     "ta-IN",
  Telugu:    "te-IN",
  Marathi:   "mr-IN",
  Bengali:   "bn-IN",
  Gujarati:  "gu-IN",
  Kannada:   "kn-IN",
  Malayalam: "ml-IN",
  Punjabi:   "pa-IN",
};

// ─────────────────────────────────────────────
// SENTENCE SPLITTER
// FIX #1: The previous code used a lookbehind assertion: /(?<=[.?!।])/
// Lookbehind is NOT supported in Safari < 16.4 (released March 2023).
// Many Indian Android devices run Chrome versions that also lack support.
// A SyntaxError here would silently kill ALL sentence splitting and TTS.
//
// Replacement: use a forward-scan match that captures the terminator
// as part of the sentence token. Universally supported since ES5.
// ─────────────────────────────────────────────

function splitIntoSentences(text: string): string[] {
  // Match: any characters (non-greedy) followed by a sentence terminator
  const matches = text.match(/[^.?!।]+[.?!।]+/g);
  return matches
    ? matches.map((s) => s.trim()).filter((s) => s.length > 2)
    : [];
}

// ─────────────────────────────────────────────
// HOOK 1: useSpeechRecognition
// ─────────────────────────────────────────────

interface SpeechRecognitionState {
  isListening:  boolean;
  isSupported:  boolean;
  transcript:   string;
  error:        string | null;
}

interface SpeechRecognitionControls {
  startListening:  (languageCode?: string) => void;
  stopListening:   () => void;
  resetTranscript: () => void;
}

export function useSpeechRecognition(
  onTranscriptReady: (transcript: string) => void
): SpeechRecognitionState & SpeechRecognitionControls {
  const [isListening, setIsListening] = useState(false);
  const [transcript,  setTranscript]  = useState("");
  const [error,       setError]       = useState<string | null>(null);
  const recognitionRef = useRef<any>(null);

  // FIX #2: Use useMemo instead of an inline expression.
  // Computing `isSupported` inline on every render is harmless but means it
  // appears as a variable (not a constant) in hooks lint analysis.
  // useMemo correctly memoizes a value that never changes after mount.
  const isSupported = useMemo(
    () =>
      typeof window !== "undefined" &&
      ("SpeechRecognition" in window || "webkitSpeechRecognition" in window),
    []
  );

  const stopListening = useCallback(() => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
      recognitionRef.current = null;
    }
    setIsListening(false);
  }, []);

  const startListening = useCallback(
    (languageCode: string = "en-IN") => {
      if (!isSupported) {
        setError("Voice input is not supported in this browser. Please type your message.");
        return;
      }

      // Stop any existing session before starting a new one
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }

      const SpeechRecognitionClass =
        (window as any).SpeechRecognition ||
        (window as any).webkitSpeechRecognition;

      const recognition = new SpeechRecognitionClass();
      recognition.lang             = languageCode;
      recognition.continuous       = false;  // Single utterance mode
      recognition.interimResults   = true;   // Show partial results while speaking
      recognition.maxAlternatives  = 1;

      recognition.onstart = () => {
        setIsListening(true);
        setError(null);
        setTranscript("");
      };

      recognition.onresult = (event: any) => {
        let finalTranscript   = "";
        let interimTranscript = "";

        for (let i = event.resultIndex; i < event.results.length; i++) {
          if (event.results[i].isFinal) {
            finalTranscript   += event.results[i][0].transcript;
          } else {
            interimTranscript += event.results[i][0].transcript;
          }
        }

        setTranscript(finalTranscript || interimTranscript);

        if (finalTranscript) {
          onTranscriptReady(finalTranscript.trim());
        }
      };

      recognition.onerror = (event: any) => {
        // FIX #3: Do NOT set an error state for "aborted".
        // "aborted" fires when stopListening() is called by the user or
        // by the barge-in handler. This is a normal, expected control flow —
        // not an error. Showing "Listening was cancelled." as a red error
        // banner for a deliberate user action is confusing UX.
        if (event.error === "aborted") {
          setIsListening(false);
          return;
        }

        const errorMessages: Record<string, string> = {
          "no-speech":            "No speech detected. Tap the mic and try again.",
          "audio-capture":        "Microphone access denied or unavailable.",
          "network":              "Network error during voice recognition.",
          "not-allowed":          "Microphone permission denied. Please allow mic access in browser settings.",
          "service-not-allowed":  "Speech service is not allowed. Check browser settings.",
          "bad-grammar":          "Speech grammar configuration error.",
          "language-not-supported": `Language "${languageCode}" is not supported by this browser.`,
        };

        setError(errorMessages[event.error] ?? `Voice error: ${event.error}`);
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
        recognitionRef.current = null;
      };

      recognitionRef.current = recognition;
      recognition.start();
    },
    [isSupported, onTranscriptReady]
  );

  const resetTranscript = useCallback(() => {
    setTranscript("");
    setError(null);
  }, []);

  // Abort recognition on unmount to avoid memory leaks
  useEffect(() => {
    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.abort();
      }
    };
  }, []);

  return {
    isListening,
    isSupported,
    transcript,
    error,
    startListening,
    stopListening,
    resetTranscript,
  };
}

// ─────────────────────────────────────────────
// HOOK 2: useSpeechSynthesis
// Speaks complete sentences as they arrive from the SSE delta stream.
// Does NOT wait for the full response before beginning to speak.
// ─────────────────────────────────────────────

interface SpeechSynthesisState {
  isSpeaking:   boolean;
  isSupported:  boolean;
}

interface SpeechSynthesisControls {
  speakDelta:   (token: string) => void;
  flushBuffer:  () => void;
  cancelSpeech: () => void;
  setLanguage:  (langCode: string) => void;
}

export function useSpeechSynthesis(): SpeechSynthesisState & SpeechSynthesisControls {
  const [isSpeaking, setIsSpeaking] = useState(false);

  const sentenceBufferRef  = useRef<string>("");
  const currentLangRef     = useRef<string>("en-IN");
  const utteranceQueueRef  = useRef<SpeechSynthesisUtterance[]>([]);

  const isSupported = useMemo(
    () => typeof window !== "undefined" && "speechSynthesis" in window,
    []
  );

  const speakSentence = useCallback(
    (sentence: string) => {
      if (!isSupported || !sentence.trim()) return;

      const utterance       = new SpeechSynthesisUtterance(sentence.trim());
      utterance.lang        = currentLangRef.current;
      utterance.rate        = 0.95;
      utterance.pitch       = 1.0;
      utterance.volume      = 1.0;

      // Try to find a voice matching the current language
      const voices = window.speechSynthesis.getVoices();
      const langPrefix = currentLangRef.current.split("-")[0];
      const matchingVoice = voices.find(
        (v) => v.lang === currentLangRef.current || v.lang.startsWith(langPrefix)
      );
      if (matchingVoice) utterance.voice = matchingVoice;

      utterance.onstart = () => setIsSpeaking(true);

      utterance.onend = () => {
        utteranceQueueRef.current.shift();
        if (utteranceQueueRef.current.length === 0) {
          setIsSpeaking(false);
        }
      };

      utterance.onerror = (e) => {
        // "interrupted" is expected when cancelSpeech() is called — not a real error
        if (e.error !== "interrupted" && e.error !== "canceled") {
          console.error("[TTS] Utterance error:", e.error);
        }
        setIsSpeaking(false);
      };

      utteranceQueueRef.current.push(utterance);
      window.speechSynthesis.speak(utterance);
    },
    [isSupported]
  );

  /**
   * speakDelta: Called with each SSE delta token as it arrives.
   * Accumulates into a buffer and fires speakSentence() as complete
   * sentences are detected. This creates streaming voice with zero
   * cloud TTS latency — the user hears the start of the response while
   * Gemini is still generating the rest.
   */
  const speakDelta = useCallback(
    (token: string) => {
      if (!isSupported) return;

      sentenceBufferRef.current += token;
      const buffer = sentenceBufferRef.current;

      // Find the last sentence terminator in the buffer
      let lastTerminatorIndex = -1;
      for (let i = 0; i < buffer.length; i++) {
        if (/[.?!।]/.test(buffer[i])) {
          lastTerminatorIndex = i;
        }
      }

      if (lastTerminatorIndex < 0) return; // No complete sentence yet

      // Extract complete sentences, keep the tail in the buffer
      const completePart = buffer.slice(0, lastTerminatorIndex + 1);
      sentenceBufferRef.current = buffer.slice(lastTerminatorIndex + 1);

      // FIX #1 applied: use safe cross-browser sentence splitter
      const sentences = splitIntoSentences(completePart);
      sentences.forEach(speakSentence);
    },
    [isSupported, speakSentence]
  );

  /**
   * flushBuffer: Call this when the SSE "done" event fires.
   * Speaks any remaining text in the buffer that didn't end with punctuation.
   */
  const flushBuffer = useCallback(() => {
    const remaining = sentenceBufferRef.current.trim();
    if (remaining.length > 0) {
      speakSentence(remaining);
      sentenceBufferRef.current = "";
    }
  }, [speakSentence]);

  /**
   * cancelSpeech: Implements Barge-In.
   * Must be called SYNCHRONOUSLY as the very first operation when the user
   * taps the mic while the AI is speaking. Clears the synthesis queue and
   * resets the sentence buffer in one atomic operation.
   *
   * Call order in Chat.tsx handleMicClick:
   *   1. cancelSpeech()      ← stops AI voice immediately (synchronous)
   *   2. startListening()    ← begins listening for user voice
   */
  const cancelSpeech = useCallback(() => {
    if (!isSupported) return;
    window.speechSynthesis.cancel(); // Native API — synchronous and immediate
    utteranceQueueRef.current    = [];
    sentenceBufferRef.current    = "";
    setIsSpeaking(false);
  }, [isSupported]);

  const setLanguage = useCallback((langCode: string) => {
    currentLangRef.current = langCode;
  }, []);

  // Trigger voice list loading (some browsers load voices asynchronously)
  useEffect(() => {
    if (!isSupported) return;
    window.speechSynthesis.getVoices();
    window.speechSynthesis.onvoiceschanged = () => {
      window.speechSynthesis.getVoices();
    };
  }, [isSupported]);

  // Cancel speech on component unmount to prevent orphaned audio
  useEffect(() => {
    return () => {
      if (isSupported) {
        window.speechSynthesis.cancel();
      }
    };
  }, [isSupported]);

  return {
    isSpeaking,
    isSupported,
    speakDelta,
    flushBuffer,
    cancelSpeech,
    setLanguage,
  };
}
