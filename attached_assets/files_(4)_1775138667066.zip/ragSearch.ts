/**
 * FILE: server/lib/ragSearch.ts
 * PURPOSE: Retrieves the top-K most relevant ICMR-NIN knowledge chunks
 *          for a given user query using cosine similarity.
 *
 * INTEGRATION NOTES FOR REPLIT:
 *  - Assumes your `knowledge_chunks` table has these columns:
 *      id        : number
 *      content   : string   (raw ICMR text chunk)
 *      embedding : number[] (pre-computed vector, stored as JSON array or pgvector)
 *      topic     : string   (e.g., "diabetes", "iron", "protein")
 *      source    : string   (e.g., "ICMR-NIN 2024 Dietary Guidelines")
 *
 *  - For tables >5,000 rows, replace the JS cosine loop with a pgvector
 *    SQL query using the <=> operator for server-side scoring.
 *
 *  - To pre-compute embeddings for ICMR chunks use Gemini:
 *      model: "text-embedding-004", taskType: "RETRIEVAL_DOCUMENT"
 *
 * DEPENDENCIES: Only uses your existing db instance. No new packages.
 */

import { db } from "../db";           // ← ADJUST to your actual db export path
import { knowledgeChunks } from "../db/schema"; // ← ADJUST to your schema export

// ─────────────────────────────────────────────
// CONSTANTS
// ─────────────────────────────────────────────

// FIX #1 (was missing): Hard cap on rows fetched for in-process cosine scoring.
// Without this, a full table scan loads ALL embedding vectors into Node RAM.
// 1000 rows × 768-float embedding = ~3MB. Still fast. Anything over 5000 rows
// warrants switching to pgvector with server-side <=> operator.
const MAX_CHUNK_ROWS = 1_000;

// FIX #2 (was missing): Hard timeout on the Gemini embedding API call.
// Without this, a stalled API call hangs the entire Promise.all in
// assembleChatContext forever, freezing every chat request.
const EMBED_TIMEOUT_MS = 5_000;

// ─────────────────────────────────────────────
// TYPES
// ─────────────────────────────────────────────

export interface RagChunk {
  content: string;
  topic: string;
  source: string;
  score: number;
}

interface KnowledgeChunkRow {
  id: number;
  content: string;
  embedding: number[] | string; // Drizzle may return JSON column as string
  topic: string;
  source: string;
}

// ─────────────────────────────────────────────
// COSINE SIMILARITY  (pure JS — no dependencies)
// Replace with pgvector <=> for large tables
// ─────────────────────────────────────────────

function cosineSimilarity(vecA: number[], vecB: number[]): number {
  if (vecA.length !== vecB.length || vecA.length === 0) return 0;

  let dot = 0;
  let magA = 0;
  let magB = 0;

  for (let i = 0; i < vecA.length; i++) {
    dot  += vecA[i] * vecB[i];
    magA += vecA[i] * vecA[i];
    magB += vecB[i] * vecB[i];
  }

  const magnitude = Math.sqrt(magA) * Math.sqrt(magB);
  return magnitude === 0 ? 0 : dot / magnitude;
}

// ─────────────────────────────────────────────
// EMBED QUERY  —  Gemini Embedding API
// ─────────────────────────────────────────────

async function embedQuery(queryText: string): Promise<number[]> {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) throw new Error("GEMINI_API_KEY not set in environment");

  // FIX #3: Enforce timeout with AbortController so a stalled embedding
  // call cannot block the entire request pipeline indefinitely.
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), EMBED_TIMEOUT_MS);

  let response: Response;
  try {
    response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/text-embedding-004:embedContent?key=${apiKey}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "models/text-embedding-004",
          content: { parts: [{ text: queryText }] },
          taskType: "RETRIEVAL_QUERY",
        }),
        signal: controller.signal,
      }
    );
  } finally {
    // Always clear the timeout whether the fetch succeeded or threw
    clearTimeout(timeoutId);
  }

  if (!response.ok) {
    const errText = await response.text().catch(() => "(unreadable body)");
    throw new Error(`Embedding API failed (HTTP ${response.status}): ${errText}`);
  }

  const data = await response.json();

  // FIX #4: Validate response shape before accessing nested properties.
  // Quota-exceeded, rate-limited, or malformed responses do NOT contain
  // data.embedding.values. Accessing it without this check crashes the server.
  if (!data?.embedding?.values || !Array.isArray(data.embedding.values)) {
    throw new Error(
      `Embedding API returned unexpected shape. Body: ${JSON.stringify(data).slice(0, 300)}`
    );
  }

  return data.embedding.values as number[];
}

// ─────────────────────────────────────────────
// HEALTH QUERY GATE
// Only embed queries that are likely health/nutrition related.
// FIX #5: Replaced overly broad terms ("good", "bad", "safe") with
// specific domain terms. The old list matched almost every English sentence.
// ─────────────────────────────────────────────

const HEALTH_KEYWORDS: string[] = [
  // Actions
  "eat", "eating", "eating", "drink", "drinking", "cook", "cooking",
  "avoid", "restrict", "substitute", "replace",
  // Meal nouns
  "food", "meal", "diet", "nutrition", "breakfast", "lunch", "dinner", "snack",
  // Indian foods
  "ghee", "dal", "roti", "sabzi", "khana", "chawal", "atta", "maida",
  "paneer", "curd", "dahi", "oil", "rice", "chapati",
  // Macros / nutrients
  "protein", "fat", "carb", "carbohydrate", "sugar", "sodium", "salt",
  "vitamin", "mineral", "calcium", "iron", "fibre", "fiber",
  "calorie", "caloric", "kcal",
  // Medical conditions
  "diabetes", "diabetic", "blood pressure", "hypertension",
  "cholesterol", "thyroid", "anemia", "anaemia", "obesity",
  // Hindi health terms
  "swasth", "sehat", "peena", "meetha", "namak", "cheeni", "motapa",
  // Medications
  "medicine", "tablet", "supplement", "medication", "drug", "metformin",
  // Clinical terms
  "glycemic", "insulin", "hemoglobin", "absorption", "deficiency",
];

function isHealthRelatedQuery(message: string): boolean {
  const lower = message.toLowerCase();
  return HEALTH_KEYWORDS.some((kw) => lower.includes(kw));
}

// ─────────────────────────────────────────────
// MAIN EXPORT: runRagSearch
// ─────────────────────────────────────────────

/**
 * Searches the knowledge_chunks table for the most relevant ICMR-NIN chunks.
 *
 * @param userMessage  - The raw user message to embed and search against
 * @param topK         - Max chunks to return (default: 4)
 * @param minScore     - Minimum cosine similarity to include a chunk (default: 0.75)
 *                       Below this, the chunk adds noise more than signal.
 * @returns            - Sorted array of RagChunk objects, best match first
 */
export async function runRagSearch(
  userMessage: string,
  topK: number = 4,
  minScore: number = 0.75
): Promise<RagChunk[]> {
  // Gate: skip embedding API call for non-health queries
  if (!isHealthRelatedQuery(userMessage)) {
    return [];
  }

  // Embed the query
  let queryVector: number[];
  try {
    queryVector = await embedQuery(userMessage);
  } catch (err) {
    // Fail gracefully — chat still works, just without ICMR grounding
    console.error("[RAG] Embedding failed, skipping RAG injection:", err);
    return [];
  }

  // Fetch a bounded set of chunks from the database
  let rows: KnowledgeChunkRow[];
  try {
    rows = (await db
      .select()
      .from(knowledgeChunks)
      .limit(MAX_CHUNK_ROWS)) as KnowledgeChunkRow[];
  } catch (err) {
    console.error("[RAG] DB fetch failed:", err);
    return [];
  }

  if (!rows || rows.length === 0) {
    console.warn("[RAG] knowledge_chunks table is empty. No ICMR data injected.");
    return [];
  }

  // Score each chunk against the query vector
  const scored = rows
    .map((row): RagChunk | null => {
      let embedding: number[];

      if (typeof row.embedding === "string") {
        try {
          embedding = JSON.parse(row.embedding);
        } catch {
          return null; // skip malformed row
        }
      } else if (Array.isArray(row.embedding)) {
        embedding = row.embedding;
      } else {
        return null; // skip unexpected type
      }

      if (embedding.length === 0) return null;

      return {
        content: row.content,
        topic:   row.topic  ?? "general",
        source:  row.source ?? "ICMR-NIN",
        score:   cosineSimilarity(queryVector, embedding),
      };
    })
    .filter((item): item is RagChunk => item !== null && item.score >= minScore);

  scored.sort((a, b) => b.score - a.score);
  const results = scored.slice(0, topK);

  if (results.length === 0) {
    console.info("[RAG] No chunks met minScore =", minScore);
  } else {
    console.info(
      `[RAG] Injecting ${results.length} chunk(s). Top score: ${results[0].score.toFixed(3)}`
    );
  }

  return results;
}

// ─────────────────────────────────────────────
// FORMAT FOR PROMPT INJECTION
// ─────────────────────────────────────────────

/**
 * Renders RagChunks into a labelled text block ready for prompt injection.
 * Returns "" when chunks is empty — safe to concat unconditionally.
 */
export function formatRagChunksForPrompt(chunks: RagChunk[]): string {
  if (chunks.length === 0) return "";

  const lines = chunks.map(
    (chunk, i) =>
      `[ICMR Evidence ${i + 1}] ` +
      `(Topic: ${chunk.topic} | Source: ${chunk.source} | ` +
      `Relevance: ${(chunk.score * 100).toFixed(1)}%)\n${chunk.content}`
  );

  return `### ICMR EVIDENCE\n${lines.join("\n\n")}`;
}
