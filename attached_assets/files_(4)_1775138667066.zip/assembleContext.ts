/**
 * FILE: server/lib/assembleContext.ts
 * PURPOSE: Assembles the complete "State Payload" context string that is injected
 *          into every Gemini call. Gemini NEVER operates on raw user messages alone.
 *
 * INTEGRATION NOTES FOR REPLIT:
 *  ─── TABLE NAMES ───
 *  Adjust the schema imports to match your actual Drizzle schema file.
 *  If your column names differ, only change the column references — not the logic.
 *
 *  ─── ASSUMED SCHEMA ───
 *  familyMembers  : { id, familyId, name, age, role, conditions (JSON[]),
 *                     dietaryRestrictions (JSON[]) }
 *  mealPlans      : { id, familyId, date (string "YYYY-MM-DD"), breakfast,
 *                     lunch, dinner, snacks, breakfastNutrition (JSON),
 *                     lunchNutrition (JSON), dinnerNutrition (JSON) }
 *  foodLogs       : { id, familyId, memberId, loggedAt (timestamp/ISO string),
 *                     mealName, calories, sodium, fat, carbs, isUnplanned (bool) }
 *  medications    : { id, familyId, memberId, drugName, dosage,
 *                     timings (JSON[] of "HH:MM"), interactions (JSON[]) }
 *
 *  ─── ALL QUERIES ARE PARALLEL ───
 *  Uses Promise.all — total DB time is max(slowest query), not sum of all.
 */

import { db } from "../db"; // ← ADJUST PATH
import {
  // FIX #1: Removed `families` — it was imported but never used anywhere
  // in this file. Keeping it would cause a TS error if the schema doesn't
  // export it by that name, and a lint warning regardless.
  familyMembers,
  mealPlans,
  foodLogs,
  medications,
} from "../db/schema"; // ← ADJUST to your schema exports
import { eq, and, gte, desc } from "drizzle-orm";
import { runRagSearch, formatRagChunksForPrompt } from "./ragSearch";

// ─────────────────────────────────────────────
// TYPES
// ─────────────────────────────────────────────

interface FamilyMember {
  id: number;
  name: string;
  age: number;
  role: string;
  conditions: string[];
  dietaryRestrictions: string[];
}

interface MealPlan {
  date: string;
  breakfast: string;
  lunch: string;
  dinner: string;
  snacks: string;
  breakfastNutrition: Record<string, number> | null;
  lunchNutrition: Record<string, number> | null;
  dinnerNutrition: Record<string, number> | null;
}

interface FoodLog {
  memberName: string;
  loggedAt: string;
  mealName: string;
  calories: number;
  sodium: number;
  fat: number;
  carbs: number;
  isUnplanned: boolean;
}

interface Medication {
  memberName: string;
  drugName: string;
  dosage: string;
  timings: string[];
  interactions: string[];
}

export interface AssembledContext {
  contextString: string;   // Full text block injected into the prompt
  hasMedications: boolean; // Convenience flag for route-level logic
  memberCount: number;
}

// ─────────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────────

function getTodayDateString(): string {
  // Returns "YYYY-MM-DD" in IST
  return new Date()
    .toLocaleDateString("en-CA", { timeZone: "Asia/Kolkata" }); // en-CA = ISO date format
}

function getSevenDaysAgoISO(): string {
  // FIX #2: Returns an ISO 8601 string instead of a Date object.
  // Passing a Date object to drizzle's gte() works for timestamp columns in
  // Postgres but silently fails for text/varchar date columns. The ISO string
  // works correctly for ALL column types and all Drizzle adapters.
  const d = new Date();
  d.setDate(d.getDate() - 7);
  return d.toISOString();
}

function safeParseJson<T>(value: unknown, fallback: T): T {
  if (Array.isArray(value)) return value as unknown as T;
  if (value !== null && typeof value === "object") return value as T;
  if (typeof value === "string") {
    try {
      return JSON.parse(value) as T;
    } catch {
      return fallback;
    }
  }
  return fallback;
}

function formatNutrition(n: Record<string, number> | null): string {
  if (!n || typeof n !== "object" || Object.keys(n).length === 0) {
    return "nutrition not available";
  }
  return Object.entries(n)
    .map(([k, v]) => `${k}: ${v}`)
    .join(", ");
}

// FIX #3: Safe date formatter — guards against null/invalid loggedAt values.
// new Date(null) returns epoch (1970-01-01), new Date(undefined) = Invalid Date.
// Both would produce misleading timestamps in the AI's context.
function safeFormatDate(value: unknown): string {
  if (!value) return "Unknown time";
  const d = new Date(value as string | number);
  if (isNaN(d.getTime())) return "Unknown time";
  return d.toLocaleString("en-IN", { timeZone: "Asia/Kolkata" });
}

// ─────────────────────────────────────────────
// MAIN EXPORT: assembleChatContext
// ─────────────────────────────────────────────

/**
 * Assembles the complete state payload for a Gemini prompt call.
 *
 * @param familyId    - The authenticated family's ID (from session)
 * @param userMessage - The raw user message (used for RAG embedding)
 * @returns           - AssembledContext with the full formatted context string
 */
export async function assembleChatContext(
  familyId: number,
  userMessage: string
): Promise<AssembledContext> {
  // FIX #4: Validate familyId before hitting the database.
  // The route handler casts session data with `as number` which doesn't
  // actually validate the type at runtime. A NaN or 0 ID would silently
  // query with a broken WHERE clause and return empty/wrong results.
  if (!Number.isInteger(familyId) || familyId <= 0) {
    throw new Error(`Invalid familyId: ${familyId}`);
  }

  const today = getTodayDateString();
  const sevenDaysAgoISO = getSevenDaysAgoISO();

  // ─────────────────────────────────────────────
  // Parallel DB queries + RAG search
  // All five fire simultaneously — total latency = slowest single query
  // ─────────────────────────────────────────────

  const [membersRaw, mealPlanRaw, logsRaw, medicationsRaw, ragChunks] =
    await Promise.all([
      // 1. Family member profiles
      db
        .select()
        .from(familyMembers)
        .where(eq(familyMembers.familyId, familyId)),

      // 2. Today's meal plan
      db
        .select()
        .from(mealPlans)
        .where(
          and(
            eq(mealPlans.familyId, familyId),
            eq(mealPlans.date, today)
          )
        )
        .limit(1),

      // 3. Last 7 days of food logs
      // FIX #2 applied: using ISO string instead of Date object for gte()
      db
        .select({
          id:          foodLogs.id,
          memberId:    foodLogs.memberId,
          loggedAt:    foodLogs.loggedAt,
          mealName:    foodLogs.mealName,
          calories:    foodLogs.calories,
          sodium:      foodLogs.sodium,
          fat:         foodLogs.fat,
          carbs:       foodLogs.carbs,
          isUnplanned: foodLogs.isUnplanned,
        })
        .from(foodLogs)
        .where(
          and(
            eq(foodLogs.familyId, familyId),
            gte(foodLogs.loggedAt, sevenDaysAgoISO)
          )
        )
        .orderBy(desc(foodLogs.loggedAt))
        .limit(20), // Caps prompt size — 20 entries is more than sufficient context

      // 4. Active medications for all family members
      db
        .select()
        .from(medications)
        .where(eq(medications.familyId, familyId)),

      // 5. RAG vector search (runs in parallel with all DB queries)
      runRagSearch(userMessage, 4, 0.75),
    ]);

  // ─────────────────────────────────────────────
  // Build member name lookup map  (memberId → FamilyMember)
  // Used to resolve member names in food logs and medications
  // ─────────────────────────────────────────────

  const memberMap = new Map<number, FamilyMember>();

  const processedMembers: FamilyMember[] = (membersRaw as any[]).map((m) => {
    const member: FamilyMember = {
      id:                 m.id,
      name:               m.name ?? "Unknown",
      age:                m.age  ?? 0,
      role:               m.role ?? "member",
      conditions:         safeParseJson<string[]>(m.conditions, []),
      dietaryRestrictions: safeParseJson<string[]>(m.dietaryRestrictions, []),
    };
    memberMap.set(m.id, member);
    return member;
  });

  // ─────────────────────────────────────────────
  // Process meal plan
  // ─────────────────────────────────────────────

  const rawPlan = (mealPlanRaw as any[])[0];
  const mealPlan: MealPlan | null = rawPlan
    ? {
        date:                rawPlan.date,
        breakfast:           rawPlan.breakfast  ?? "Not planned",
        lunch:               rawPlan.lunch       ?? "Not planned",
        dinner:              rawPlan.dinner      ?? "Not planned",
        snacks:              rawPlan.snacks      ?? "None",
        breakfastNutrition:  safeParseJson<Record<string, number> | null>(rawPlan.breakfastNutrition, null),
        lunchNutrition:      safeParseJson<Record<string, number> | null>(rawPlan.lunchNutrition,     null),
        dinnerNutrition:     safeParseJson<Record<string, number> | null>(rawPlan.dinnerNutrition,    null),
      }
    : null;

  // ─────────────────────────────────────────────
  // Process food logs
  // ─────────────────────────────────────────────

  const processedLogs: FoodLog[] = (logsRaw as any[]).map((log) => ({
    memberName:  memberMap.get(log.memberId)?.name ?? "Unknown member",
    loggedAt:    safeFormatDate(log.loggedAt), // FIX #3 applied
    mealName:    log.mealName   ?? "Unnamed meal",
    calories:    log.calories   ?? 0,
    sodium:      log.sodium     ?? 0,
    fat:         log.fat        ?? 0,
    carbs:       log.carbs      ?? 0,
    isUnplanned: log.isUnplanned ?? false,
  }));

  // ─────────────────────────────────────────────
  // Process medications
  // ─────────────────────────────────────────────

  const processedMeds: Medication[] = (medicationsRaw as any[]).map((med) => ({
    memberName:   memberMap.get(med.memberId)?.name ?? "Unknown member",
    drugName:     med.drugName ?? "Unknown drug",
    dosage:       med.dosage   ?? "standard",
    timings:      safeParseJson<string[]>(med.timings,      []),
    interactions: safeParseJson<string[]>(med.interactions, []),
  }));

  // ─────────────────────────────────────────────
  // Assemble the context string
  // Each section is clearly labelled so the AI can parse them reliably.
  // ─────────────────────────────────────────────

  const contextParts: string[] = [];

  // ── A: Family Profile ──
  if (processedMembers.length > 0) {
    const lines = processedMembers.map(
      (m) =>
        `  • ${m.name} | Age: ${m.age} | Role: ${m.role}` +
        (m.conditions.length > 0
          ? ` | Conditions: ${m.conditions.join(", ")}`
          : "") +
        (m.dietaryRestrictions.length > 0
          ? ` | Dietary Restrictions: ${m.dietaryRestrictions.join(", ")}`
          : "")
    );
    contextParts.push(`### FAMILY PROFILE\n${lines.join("\n")}`);
  } else {
    contextParts.push("### FAMILY PROFILE\nNo family members found for this account.");
  }

  // ── B: Today's Meal Plan ──
  if (mealPlan) {
    contextParts.push(
      `### TODAY'S MEAL PLAN (${mealPlan.date})\n` +
      `  • Breakfast: ${mealPlan.breakfast} [${formatNutrition(mealPlan.breakfastNutrition)}]\n` +
      `  • Lunch:     ${mealPlan.lunch}     [${formatNutrition(mealPlan.lunchNutrition)}]\n` +
      `  • Dinner:    ${mealPlan.dinner}    [${formatNutrition(mealPlan.dinnerNutrition)}]\n` +
      `  • Snacks:    ${mealPlan.snacks}`
    );
  } else {
    contextParts.push(
      `### TODAY'S MEAL PLAN\nNo meal plan found for today (${today}). Suggest meals appropriate for the family profile.`
    );
  }

  // ── C: Recent Food Logs ──
  if (processedLogs.length > 0) {
    const lines = processedLogs.map(
      (log) =>
        `  • [${log.loggedAt}] ${log.memberName} — ${log.mealName}` +
        ` (${log.calories} kcal | ${log.sodium}mg sodium | ${log.fat}g fat | ${log.carbs}g carbs)` +
        (log.isUnplanned ? " ⚠️ UNPLANNED" : "")
    );
    contextParts.push(`### RECENT FOOD LOGS (Last 7 Days)\n${lines.join("\n")}`);
  } else {
    contextParts.push("### RECENT FOOD LOGS\nNo food logs recorded in the last 7 days.");
  }

  // ── D: Medication Rules ──
  if (processedMeds.length > 0) {
    const lines = processedMeds.map(
      (med) =>
        `  • ${med.memberName} takes ${med.drugName} (${med.dosage})` +
        (med.timings.length > 0 ? ` at: ${med.timings.join(", ")}` : " — timing not logged") +
        (med.interactions.length > 0
          ? ` | Food interactions: ${med.interactions.join("; ")}`
          : "")
    );
    contextParts.push(`### MEDICATION RULES\n${lines.join("\n")}`);
  } else {
    contextParts.push("### MEDICATION RULES\nNo active medications on record.");
  }

  // ── E: ICMR RAG Evidence ──
  const ragText = formatRagChunksForPrompt(ragChunks);
  contextParts.push(
    ragText || "### ICMR EVIDENCE\nNo relevant ICMR-NIN guidelines found for this specific query."
  );

  // ── F: Current IST Time ──
  const timeStr = new Date().toLocaleTimeString("en-IN", {
    hour: "2-digit", minute: "2-digit", hour12: true,
    timeZone: "Asia/Kolkata",
  });
  contextParts.push(`### CURRENT TIME (IST)\n  ${timeStr} on ${today}`);

  return {
    contextString:   contextParts.join("\n\n"),
    hasMedications:  processedMeds.length > 0,
    memberCount:     processedMembers.length,
  };
}
